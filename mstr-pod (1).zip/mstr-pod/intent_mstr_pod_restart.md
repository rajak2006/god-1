# intent.md

# MicroStrategy OCP Restart & Audit Automation

## Objective

Create a professional Confluence-style documentation page and operational knowledge base for the MicroStrategy Restart & Audit Automation framework running on Kubernetes/OpenShift using Ansible automation.

The generated documentation should support:
- Engineering teams
- Platform/SRE teams
- Operations teams
- Management stakeholders
- Audit and compliance reviews

The output should be suitable for:
- Confluence publishing
- Claude Code ingestion
- Technical presentations
- SOP creation
- Resume/project documentation

---

# High-Level Goal

Implement an enterprise-grade automation framework that performs:

1. Automated restart of MicroStrategy components
2. Pod and container-level validation
3. Intelligent failure detection
4. Centralized audit collection
5. HTML report generation
6. Operational visibility and reliability improvement

Core workflow:

Input → Restart → Validation → Audit → Report

---

# Scope

## Environments
- Development (Dev)
- QA
- UAT
- Production

## Components Covered
- Intelligence Server (IServer)
- Library
- Web
- Supporting services

---

# Architecture Overview

## Workflow Pipeline

```text
vars.yml
↓
restart_targets
↓
process_component.yml
↓
audit_results
↓
collect-pods.yml
↓
pods
↓
template module
↓
Jinja2 rendering
↓
Final HTML Report
```

---

# Input Layer

## File
`vars.yml`

## Purpose
Defines:
- Namespace
- Components to restart
- Selectors used for pod discovery

## Example

```yaml
namespace: mstr-env

restart_targets:
  - name: library
    selector: library

  - name: iserver
    selector: iserver
```

## Design Logic
- Dynamic selector-based matching
- No hardcoded pod names
- Multi-environment support
- Scalable component onboarding

---

# Restart Layer

## File
`restart.yml`

## Functionality
Triggers restart of:
- Deployments
- StatefulSets

## Commands

```bash
oc rollout restart deployment <deployment-name>
oc rollout restart statefulset <statefulset-name>
```

## Key Features
- Safe execution
- Supports mixed workloads
- Non-blocking execution
- Automated restart handling

---

# Validation Layer (Core Logic)

## File
`process_component.yml`

This is the most critical module of the automation.

---

## Pod Discovery

### Command

```bash
oc get pods -o json
```

### Why JSON Parsing
- Structured data
- Reliable automation
- Avoids grep/awk parsing issues
- Easier failure handling

---

## Dynamic Pod Filtering

### Logic

```jinja2
selectattr('metadata.name','search', item.selector)
```

### Purpose
- Dynamic pod discovery
- Environment-independent logic
- Selector-driven architecture

---

## Pod Phase Validation

### Validation

```text
.status.phase == Running
```

### Purpose
Ensures pod is started successfully.

### Important Note
Pod Running alone is NOT sufficient.

---

## Container-Level Validation (Critical)

### Validation

```text
.status.containerStatuses[*].ready == true
```

### Why This Matters

A pod can show:
- Running
- But containers may not be ready

Example:

```text
1/2 Running → PARTIAL FAILURE
```

This automation prevents false-positive reporting.

---

## Failed Container Detection

### Logic

```jinja2
selectattr('ready','equalto', false)
```

### Example Output

```yaml
failed_containers:
  - iserver
```

---

## Final Status Logic

### SUCCESS
- Pod = Running
- All containers ready

### FAILED
- Pod not running
OR
- Any container not ready

---

## Audit Data Creation

### Example

```yaml
audit_results:
  - component: library
    pod: mstr-env-library-abc
    status: SUCCESS
    failed_containers: []
```

---

# Cluster Visibility Layer

## File
`collect-pods.yml`

## Function

Collects all pods in the namespace.

### Command

```bash
oc get pods -o json
```

## Benefits
- Full cluster visibility
- Easier troubleshooting
- Debugging support
- Report enrichment

---

# Reporting Layer

## File
`mstr_full_audit_report.html.j2`

## Technology
- Ansible
- Jinja2
- HTML

---

## Data Sources

| Variable | Source |
|---|---|
| namespace | vars.yml |
| audit_results | process_component.yml |
| pods | collect-pods.yml |
| ansible_date_time | Ansible facts |

---

## Rendering Logic

### Loop

```jinja2
{% for item in audit_results %}
```

### Conditional Rendering

```jinja2
{% if item.status == 'SUCCESS' %}
```

### Output

| Status | Display |
|---|---|
| SUCCESS | Green |
| FAILED | Red |

---

# Output Layer

## Generated Report

```text
/tmp/mstr_audit_report_<namespace>.html
```

## Report Includes
- Restart audit summary
- Component status
- Pod details
- Failed containers
- Full pod list
- Cluster visibility

---

# Failure Handling Logic

| Scenario | Detection |
|---|---|
| Pod Running but container failed | containerStatuses |
| Pod Pending | timeout/retry |
| CrashLoopBackOff | phase + restart pattern |
| No pod found | selector mismatch |

---

# Key Engineering Strengths

## Reliability
- Retry-based validation
- Timeout control
- Automated verification

## Accuracy
- Container-level checks
- No false positives

## Scalability
- Dynamic selectors
- Multi-component support

## Maintainability
- Modular role design
- Clear layer separation

## Non-Blocking Design
- Workflow continues during failures
- Errors captured in reports

---

# Business Benefits

- Reduced manual effort
- Faster issue detection
- Improved operational reliability
- Standardized audit reporting
- Better management visibility
- Improved SRE maturity
- Reduced troubleshooting time

---

# Manager-Level Summary

## What This Automation Does

- Restarts MicroStrategy services automatically
- Validates pod and container health
- Detects hidden failures
- Generates centralized HTML reports

---

## Simple Flow

```text
Restart → Validate → Report
```

---

## Validation Strength

The automation validates:
- Pod health
- Container readiness
- Failure scenarios
- Partial failures

Example:
- Pod Running but 1/2 containers ready = FAILED

---

## Executive Value Statement

This automation ensures every restart is properly validated and clearly reported, improving reliability, operational transparency, and platform stability.

---

# Resume / Project Summary

## Professional Summary

Designed and implemented end-to-end automation for MicroStrategy restart operations in Kubernetes/OpenShift using Ansible, enabling container-level validation, dynamic pod discovery, intelligent failure detection, and centralized HTML audit reporting aligned with SRE best practices.

---

# SOP Guidance

## Purpose

Provide a controlled and auditable process for:
- Restarting MicroStrategy workloads
- Validating service health
- Capturing operational audit evidence

---

## Typical Restart Scenarios

- Memory leaks
- Performance degradation
- Deployment updates
- CrashLoopBackOff
- Pod readiness failures
- Post-maintenance validation

---

## Recommended Restart Method

```bash
oc rollout restart deployment <name>
```

Preferred over force deleting pods.

---

# Monitoring & Validation

## Tools
- Prometheus
- Grafana
- OpenShift Monitoring

## Metrics
- Pod status
- Container readiness
- Restart counts
- CPU/Memory utilization

---

# Best Practices

- Always use rolling restart
- Validate containers, not only pods
- Avoid unnecessary restarts
- Schedule during low-usage windows
- Maintain audit records
- Automate reporting

---

# Future Enhancements

- Grafana integration
- Slack/email notifications
- Historical report retention
- Multi-cluster support
- CPU/Memory analytics
- Automated remediation

---

# Final Technical Summary

This automation framework provides enterprise-grade restart validation using Ansible, Kubernetes/OpenShift, JSON-based pod discovery, dynamic selectors, deep container-level health checks, and centralized HTML audit reporting.

It aligns with modern SRE and DevOps operational standards while improving reliability, visibility, scalability, and operational governance.
