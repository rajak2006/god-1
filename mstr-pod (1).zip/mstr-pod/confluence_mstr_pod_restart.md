# MicroStrategy OCP Restart & Audit Automation

**Document Type:** Technical Runbook & Architecture Reference
**Audience:** Engineering, Platform/SRE, Operations, Management, Audit & Compliance
**Status:** Active
**Last Reviewed:** 2026-05-07

---

## Table of Contents

1. [Overview](#1-overview)
2. [Objectives](#2-objectives)
3. [Scope](#3-scope)
4. [Architecture & Workflow](#4-architecture--workflow)
5. [Component Reference](#5-component-reference)
6. [Validation Logic (Deep Dive)](#6-validation-logic-deep-dive)
7. [Reporting & Output](#7-reporting--output)
8. [Monitoring & Observability](#8-monitoring--observability)
9. [Key Engineering Strengths](#9-key-engineering-strengths)
10. [Business Benefits](#10-business-benefits)
11. [Standard Operating Procedure (SOP)](#11-standard-operating-procedure-sop)
12. [Best Practices](#12-best-practices)
13. [Dependencies](#13-dependencies)
14. [Risks & Considerations](#14-risks--considerations)
15. [Future Enhancements](#15-future-enhancements)
16. [Next Steps](#16-next-steps)
17. [Appendix A — Executive Summary](#appendix-a--executive-summary)
18. [Appendix B — Professional Summary](#appendix-b--professional-summary-resume--project-reference)

---

## 1. Overview

> **Info:** This document describes the design, operation, and governance of the MicroStrategy Restart & Audit Automation framework deployed on Kubernetes / OpenShift (OCP) and orchestrated via Ansible.

The **MicroStrategy OCP Restart & Audit Automation** framework is an enterprise-grade operational tool designed to automate the lifecycle of MicroStrategy service restarts across Kubernetes/OpenShift environments. It combines intelligent pod and container-level health validation, dynamic component discovery, and centralized HTML audit reporting into a single, cohesive pipeline.

This framework eliminates manual restart procedures, prevents false-positive health reporting, and produces a structured, auditable evidence trail for every operation — aligning with modern SRE and DevOps operational maturity standards.

**Core Workflow Summary:**

```
Input (vars.yml) → Restart → Validation → Audit Collection → HTML Report
```

---

## 2. Objectives

The automation framework was built to fulfill the following operational and engineering objectives:

| # | Objective | Description |
|---|---|---|
| 1 | Automated Restart | Eliminate manual intervention for routine MicroStrategy service restarts |
| 2 | Pod-Level Validation | Confirm pods transition to a Running state after restart |
| 3 | Container-Level Validation | Validate that **all containers** within each pod are Ready — not just the pod itself |
| 4 | Intelligent Failure Detection | Detect partial failures (e.g., 1 of 2 containers ready) that standard monitoring can miss |
| 5 | Centralized Audit Collection | Aggregate restart results into a structured audit dataset per run |
| 6 | HTML Report Generation | Produce a human-readable, color-coded audit report for operational and compliance use |
| 7 | Operational Visibility | Provide SRE and platform teams full namespace-level pod visibility during each run |
| 8 | Platform Reliability | Improve platform stability through consistent, validated, and repeatable restart procedures |

---

## 3. Scope

### 3.1 Target Environments

This framework is designed to operate across all standard deployment tiers:

| Environment | Description |
|---|---|
| Development (Dev) | Local integration testing and automation development |
| QA | Quality assurance and regression validation |
| UAT | User acceptance testing prior to production release |
| Production | Live customer-facing environment |

### 3.2 MicroStrategy Components Covered

| Component | Description |
|---|---|
| Intelligence Server (IServer) | Core analytics and computation engine |
| Library | MicroStrategy Library web application |
| Web | MicroStrategy Web portal |
| Supporting Services | Ancillary microservices and platform dependencies |

> **Note:** Additional components can be onboarded dynamically by updating `vars.yml` — no code changes required.

---

## 4. Architecture & Workflow

### 4.1 High-Level Pipeline

The automation is structured as a layered pipeline. Each layer has a single, clearly defined responsibility:

```
┌─────────────────────────────────────────────────────────────────┐
│                         vars.yml                                │
│             (Input: Namespace, Components, Selectors)           │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                    restart_targets                               │
│           (Component list passed to restart layer)              │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                  process_component.yml                          │
│    (Pod Discovery → Phase Check → Container Validation →        │
│                  Failure Detection → Audit Entry)               │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                     audit_results                               │
│          (Structured per-component validation data)             │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                    collect-pods.yml                             │
│          (Full namespace pod inventory collection)              │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│            mstr_full_audit_report.html.j2                       │
│              (Jinja2 Template → HTML Rendering)                 │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│            /tmp/mstr_audit_report_<namespace>.html              │
│                    (Final HTML Report)                          │
└─────────────────────────────────────────────────────────────────┘
```

### 4.2 Layer Summary

| Layer | File | Responsibility |
|---|---|---|
| Input | `vars.yml` | Defines namespace, target components, and selectors |
| Restart | `restart.yml` | Triggers rolling restart of Deployments and StatefulSets |
| Validation | `process_component.yml` | Pod discovery, health checks, container readiness, audit data |
| Visibility | `collect-pods.yml` | Full namespace pod inventory |
| Reporting | `mstr_full_audit_report.html.j2` | Jinja2-rendered HTML audit report |
| Output | `/tmp/mstr_audit_report_<namespace>.html` | Final deliverable HTML report |

---

## 5. Component Reference

### 5.1 Input Layer — `vars.yml`

**Purpose:** Single source of truth for automation configuration. All namespace, component, and selector definitions originate here.

**Key Fields:**

| Field | Description |
|---|---|
| `namespace` | Target Kubernetes/OpenShift namespace |
| `restart_targets` | List of components to restart (name + selector) |
| `selector` | Label selector used for dynamic pod discovery |

**Example Configuration:**

```yaml
namespace: mstr-env

restart_targets:
  - name: library
    selector: library

  - name: iserver
    selector: iserver
```

**Design Principles:**

- No hardcoded pod names — all discovery is selector-driven
- Multi-environment support via namespace parameter
- New components added by appending entries — zero code changes required
- Fully scalable component onboarding

---

### 5.2 Restart Layer — `restart.yml`

**Purpose:** Performs safe, rolling restarts of MicroStrategy workloads using OpenShift/Kubernetes native commands.

**Supported Workload Types:**

| Workload Type | Command |
|---|---|
| Deployment | `oc rollout restart deployment <name>` |
| StatefulSet | `oc rollout restart statefulset <name>` |

**Design Characteristics:**

| Feature | Description |
|---|---|
| Safe Execution | Uses native `oc rollout restart` — avoids disruptive force-delete patterns |
| Mixed Workloads | Handles both Deployments and StatefulSets in a single run |
| Non-Blocking | Restart is triggered asynchronously; validation occurs separately |
| Automated Handling | No manual pod deletion or annotation patching required |

> **Warning:** Force-deleting pods (`oc delete pod`) bypasses proper pod lifecycle management and is **not recommended**. Always use `oc rollout restart`.

---

### 5.3 Validation Layer — `process_component.yml`

> **This is the most critical module of the automation framework.**

This module performs multi-level health validation for every target component. It goes beyond simple pod status checks to validate at the container level — preventing false-positive reporting.

#### 5.3.1 Pod Discovery

```bash
oc get pods -o json
```

**Why JSON?**

| Reason | Benefit |
|---|---|
| Structured Data | Reliable, machine-parseable output |
| Automation-Safe | No dependency on grep/awk string parsing |
| Error Resilience | Missing fields return empty values, not parse errors |
| Full Metadata | All pod and container attributes available for complex logic |

#### 5.3.2 Dynamic Pod Filtering

```jinja2
selectattr('metadata.name', 'search', item.selector)
```

**Purpose:** Matches pods whose names contain the configured selector string — supports dynamic discovery across any environment without hardcoded names.

#### 5.3.3 Pod Phase Validation

```
.status.phase == "Running"
```

Confirms the pod has started and is in an active lifecycle state.

> **Important:** Pod `Running` state alone is **not sufficient** to confirm service health. A pod can report Running while its containers are still initializing or have failed.

#### 5.3.4 Container-Level Validation (Critical)

```
.status.containerStatuses[*].ready == true
```

**Why This Matters:**

A pod with multiple containers can show a `Running` phase while one or more containers are not ready. Standard monitoring often misses this condition.

```
Example: Pod Status = Running | Containers = 1/2 Ready → PARTIAL FAILURE
```

This automation explicitly catches and reports this scenario, **preventing false-positive health reporting**.

#### 5.3.5 Failed Container Detection

```jinja2
selectattr('ready', 'equalto', false)
```

**Example Output:**

```yaml
failed_containers:
  - iserver
```

#### 5.3.6 Final Status Logic

| Condition | Status |
|---|---|
| Pod = Running AND all containers ready | **SUCCESS** |
| Pod not Running | **FAILED** |
| Pod Running but any container not ready | **FAILED** |

#### 5.3.7 Audit Data Structure

Each component generates a structured audit entry:

```yaml
audit_results:
  - component: library
    pod: mstr-env-library-abc123
    status: SUCCESS
    failed_containers: []

  - component: iserver
    pod: mstr-env-iserver-xyz789
    status: FAILED
    failed_containers:
      - iserver
```

---

### 5.4 Cluster Visibility Layer — `collect-pods.yml`

**Purpose:** Collects a complete inventory of all pods in the target namespace — independent of the restart targets.

```bash
oc get pods -o json
```

**Benefits:**

| Benefit | Description |
|---|---|
| Full Cluster Visibility | Operators see all pods, not just restarted ones |
| Troubleshooting Support | Identify unrelated pod failures during the same window |
| Report Enrichment | Adds comprehensive pod listing to the HTML report |
| Debugging Aid | Provides full namespace context for post-run analysis |

---

### 5.5 Reporting Layer — `mstr_full_audit_report.html.j2`

**Technology Stack:** Ansible + Jinja2 + HTML

#### Data Sources

| Variable | Source | Description |
|---|---|---|
| `namespace` | `vars.yml` | Target environment identifier |
| `audit_results` | `process_component.yml` | Per-component restart and health results |
| `pods` | `collect-pods.yml` | Full pod inventory for the namespace |
| `ansible_date_time` | Ansible facts | Report timestamp |

#### Rendering Logic

**Loop over components:**

```jinja2
{% for item in audit_results %}
  ...render component row...
{% endfor %}
```

**Conditional status rendering:**

```jinja2
{% if item.status == 'SUCCESS' %}
  <span style="color: green;">SUCCESS</span>
{% else %}
  <span style="color: red;">FAILED</span>
{% endif %}
```

**Visual Status Indicators:**

| Status | Color | Meaning |
|---|---|---|
| SUCCESS | Green | Pod running, all containers ready |
| FAILED | Red | Pod not running or container(s) not ready |

---

### 5.6 Output Layer

**Report Path:**

```
/tmp/mstr_audit_report_<namespace>.html
```

**Report Contents:**

| Section | Description |
|---|---|
| Restart Audit Summary | Overview of all components restarted in the run |
| Component Status | Per-component SUCCESS / FAILED result |
| Pod Details | Pod name, phase, and container count |
| Failed Containers | List of specific containers that failed readiness |
| Full Pod List | Complete namespace pod inventory |
| Cluster Visibility | Additional context for troubleshooting |
| Run Timestamp | Date/time stamp from Ansible facts |

---

## 6. Validation Logic (Deep Dive)

The validation design is the core differentiator of this framework. The following table summarizes how each failure scenario is detected and handled.

### 6.1 Failure Scenario Matrix

| Failure Scenario | Detection Mechanism | Automation Handling |
|---|---|---|
| Pod Running but container failed | `containerStatuses[*].ready == false` | Captured as FAILED with container names listed |
| Pod Pending (not yet running) | `status.phase != Running` | Timeout/retry until phase transitions or timeout expires |
| CrashLoopBackOff | Phase check + container restart count pattern | Detected via container state and flagged as FAILED |
| No pod found (selector mismatch) | Empty pod list after filtering | Logged as component not found; report updated accordingly |
| Partial readiness (1/2 containers) | Container-level `ready` attribute | Counted as FAILED — partial readiness is not acceptable |

### 6.2 Why Container-Level Checks Are Non-Negotiable

Standard Kubernetes health monitoring tools and dashboards frequently report pods at the phase level (`Running`, `Pending`, `Failed`). This is **insufficient** for multi-container pods or pods with complex readiness probes.

The automation enforces a strict two-gate policy:

- **Gate 1 — Pod Phase:** Pod must be in `Running` state
- **Gate 2 — Container Readiness:** Every container in the pod must report `ready: true`

Only when both gates pass is a component marked `SUCCESS`.

---

## 7. Reporting & Output

The HTML audit report is generated at the end of every automation run and serves as the primary artifact for:

- **Operational Review:** SRE and platform teams verify restart outcomes
- **Audit & Compliance:** Documented evidence of controlled change execution
- **Incident Investigation:** Historical reference for failure analysis
- **Management Reporting:** Executive-readable summary of platform stability

**Report Example Layout:**

| Field | Example Value |
|---|---|
| Namespace | mstr-env |
| Run Timestamp | 2026-05-07 14:32:11 UTC |
| Component | library |
| Pod | mstr-env-library-abc123 |
| Status | SUCCESS |
| Failed Containers | — |

---

## 8. Monitoring & Observability

### 8.1 Tooling Integration

| Tool | Role |
|---|---|
| Prometheus | Metrics collection for pod health, restart counts, and resource usage |
| Grafana | Dashboards for visualizing pod status trends and restart history |
| OpenShift Monitoring | Native platform-level alerting and pod lifecycle monitoring |

### 8.2 Key Metrics to Monitor

| Metric | Description |
|---|---|
| Pod Status | Current phase for each MicroStrategy pod |
| Container Readiness | Number of ready vs. total containers |
| Restart Count | Number of restarts per container (high counts indicate instability) |
| CPU Utilization | Resource consumption before and after restart |
| Memory Utilization | Memory pressure that may trigger restart cycles |

---

## 9. Key Engineering Strengths

| Strength | Implementation | Value |
|---|---|---|
| **Reliability** | Retry logic, timeout control, automated verification | Eliminates flaky or incomplete restart operations |
| **Accuracy** | Container-level readiness checks | Prevents false-positive health reporting |
| **Scalability** | Dynamic selector architecture, multi-component support | Add new components without code changes |
| **Maintainability** | Modular role design, clear layer separation | Easy to extend, debug, and hand off |
| **Non-Blocking Design** | Workflow continues during partial failures | Failures are captured and reported; pipeline does not halt |
| **Audit-Ready** | Structured YAML audit results, HTML report | Every run produces compliance evidence automatically |
| **Environment Agnostic** | Namespace and selector parameterization | Same playbooks run across Dev, QA, UAT, and Production |

---

## 10. Business Benefits

| Benefit | Description |
|---|---|
| Reduced Manual Effort | Engineers no longer perform or verify restarts manually |
| Faster Issue Detection | Partial failures and container errors are caught immediately |
| Improved Operational Reliability | Consistent, validated restarts replace ad-hoc procedures |
| Standardized Audit Reporting | Every operation produces a documented, reviewable artifact |
| Better Management Visibility | HTML reports provide executive-level status at a glance |
| Improved SRE Maturity | Automation aligns with SRE principles for reliability, observability, and incident reduction |
| Reduced Troubleshooting Time | Centralized audit data and cluster visibility accelerate root cause analysis |
| Compliance Readiness | Structured evidence collection supports audit and governance requirements |

---

## 11. Standard Operating Procedure (SOP)

### 11.1 Purpose

This SOP defines the controlled and auditable process for restarting MicroStrategy workloads on OpenShift, validating service health, and capturing operational evidence.

### 11.2 When to Use This Automation

Trigger a restart using this framework under the following conditions:

| Scenario | Description |
|---|---|
| Memory Leaks | Pod memory consumption approaching limit thresholds |
| Performance Degradation | Elevated response times without a clear application-level cause |
| Deployment Updates | Following a new image rollout or configuration change |
| CrashLoopBackOff | Pod repeatedly crashing and restarting |
| Pod Readiness Failures | Containers failing liveness or readiness probes |
| Post-Maintenance Validation | Confirming service health after infrastructure or platform maintenance |

### 11.3 Execution Steps

| Step | Action | Command / Notes |
|---|---|---|
| 1 | Review `vars.yml` | Confirm namespace and target components are correct for the environment |
| 2 | Execute playbook | Run the Ansible playbook against the target environment |
| 3 | Monitor restart | Observe rollout status using `oc rollout status` |
| 4 | Review audit results | Inspect `audit_results` in playbook output or wait for HTML report |
| 5 | Review HTML report | Open `/tmp/mstr_audit_report_<namespace>.html` |
| 6 | Escalate on FAILED | If any component shows FAILED, follow incident response procedure |
| 7 | Retain report | Archive HTML report in designated audit storage location |

### 11.4 Recommended Restart Method

```bash
oc rollout restart deployment <deployment-name>
```

> **Warning:** Avoid force-deleting pods with `oc delete pod`. This bypasses proper pod lifecycle management, can cause data loss in StatefulSets, and does not trigger proper readiness validation.

---

## 12. Best Practices

| Practice | Rationale |
|---|---|
| Always use rolling restart | Prevents downtime and ensures proper lifecycle transitions |
| Validate containers, not only pods | Pod Running status is insufficient — always check container readiness |
| Avoid unnecessary restarts | Each restart introduces transient risk; only restart when required |
| Schedule during low-usage windows | Reduces user impact and simplifies health validation |
| Maintain audit records | Retained reports support compliance reviews and incident retrospectives |
| Automate reporting | Manual status checks are error-prone; reports provide ground truth |
| Review `vars.yml` before every run | Prevents accidental restarts of wrong components or wrong environment |

---

## 13. Dependencies

### 13.1 Platform Dependencies

| Dependency | Purpose |
|---|---|
| OpenShift / Kubernetes | Target runtime platform for MicroStrategy workloads |
| Ansible | Automation orchestration engine executing all playbooks |
| `oc` CLI | OpenShift CLI used for rollout restarts and pod queries |
| Jinja2 | HTML report template rendering engine |

### 13.2 Internal Module Dependencies

| Module | Depends On | Reason |
|---|---|---|
| `restart.yml` | `vars.yml` | Reads restart targets and namespace |
| `process_component.yml` | `vars.yml`, `restart.yml` | Validates post-restart pod and container state |
| `collect-pods.yml` | `vars.yml` | Queries namespace after validation |
| `mstr_full_audit_report.html.j2` | `audit_results`, `pods`, `ansible_date_time` | Requires all upstream data to render |

### 13.3 Runtime Prerequisites

| Prerequisite | Notes |
|---|---|
| Ansible controller access to OCP cluster | Service account with `get pods`, `rollout restart` permissions |
| Namespace permissions | Read access to pod status; write access to trigger rollouts |
| `oc` CLI installed on Ansible controller | Used for pod queries and rollout commands |
| Jinja2 installed | Required for HTML report rendering |

---

## 14. Risks & Considerations

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Selector mismatch — wrong pods targeted | Low | High | Review `vars.yml` before every run; validate selectors in non-prod first |
| Restart during peak usage window | Medium | High | Schedule automation during low-traffic windows; coordinate with stakeholders |
| StatefulSet restart causing data inconsistency | Low | High | Validate StatefulSet pod ordering; ensure proper PVC binding after restart |
| CrashLoopBackOff not resolving after restart | Medium | High | Investigate root cause before re-running; do not loop restart without diagnosis |
| Partial readiness flagged incorrectly | Low | Medium | Review container readiness probe configuration; ensure probes reflect true health |
| HTML report not generated (disk/permission issue) | Low | Low | Confirm `/tmp` write permissions on Ansible controller; verify Jinja2 installation |
| Report not archived — audit evidence lost | Medium | Medium | Implement automated report archival as part of the pipeline post-generation |

---

## 15. Future Enhancements

The following enhancements are planned or recommended for future iterations of this framework:

| Enhancement | Priority | Description |
|---|---|---|
| Grafana Integration | High | Push restart audit results and container health metrics to Grafana dashboards |
| Slack / Email Notifications | High | Send real-time alerts on FAILED components to on-call channels |
| Historical Report Retention | High | Persist HTML reports to object storage (S3, OCP PVC) for long-term audit access |
| Multi-Cluster Support | Medium | Extend `vars.yml` and playbook structure to target multiple OCP clusters |
| CPU / Memory Analytics | Medium | Include resource utilization metrics in audit reports pre- and post-restart |
| Automated Remediation | Medium | Trigger automated remediation workflows on detected container failures |
| Report Portal Integration | Low | Publish audit results to a centralized reporting portal for dashboarding |
| Scheduling & Calendar Integration | Low | Schedule routine restarts via CI/CD pipeline or cron-based Ansible triggers |

---

## 16. Next Steps

| Priority | Action Item | Owner | Notes |
|---|---|---|---|
| 1 | Review and validate `vars.yml` for all environments | Platform/SRE Team | Confirm selectors match current pod naming conventions |
| 2 | Execute framework in Dev and QA environments | Engineering Team | Validate end-to-end pipeline before UAT and Production rollout |
| 3 | Establish report archival process | Operations Team | Define storage location and retention policy for HTML audit reports |
| 4 | Integrate Slack notifications for FAILED components | Engineering Team | Connect to on-call alerting channel |
| 5 | Review failure handling SOP with Operations | Operations / SRE | Define escalation paths for each failure scenario in the matrix |
| 6 | Schedule Production rollout window | Platform Team | Coordinate with stakeholders for low-impact execution window |
| 7 | Configure Prometheus/Grafana dashboards | SRE Team | Surface restart metrics and container readiness in existing dashboards |
| 8 | Present to management stakeholders | Lead Engineer | Share executive summary and HTML report sample |

---

## Appendix A — Executive Summary

> This automation framework ensures every MicroStrategy service restart is properly executed, deeply validated at the container level, and clearly documented through an auditable HTML report. It replaces error-prone manual procedures with a consistent, repeatable, and observable pipeline — improving platform reliability, reducing operational risk, and providing the audit evidence required for compliance and governance reviews.

**Core Value in One Line:**
*Restart → Validate → Report — fully automated, deeply validated, always auditable.*

---

## Appendix B — Professional Summary (Resume / Project Reference)

> Designed and implemented an end-to-end automation framework for MicroStrategy restart operations on Kubernetes/OpenShift using Ansible. The solution delivers container-level health validation, dynamic selector-driven pod discovery, intelligent partial-failure detection, and centralized HTML audit reporting — aligned with SRE best practices and enterprise operational governance standards.

---

*Document generated from internal intent specification. For questions or updates, contact the Platform/SRE team.*
