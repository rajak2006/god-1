# MicroStrategy MSTRBak – Enterprise Backup Automation Framework

---

> **Document Type:** Technical Design & Implementation Guide  
> **Product:** MicroStrategy (MSTR) 11.5.1200.0232  
> **Backup Tool:** mstrbak 2.1  
> **Environment:** MicroStrategy MEP (Managed Environment Platform)  
> **Audience:** Developers, System Administrators, Operations, Enterprise Architects

---

## Table of Contents

1. [Overview](#1-overview)
2. [Objectives](#2-objectives)
3. [Scope](#3-scope)
4. [Existing Environment](#4-existing-environment)
5. [Key Features & Requirements](#5-key-features--requirements)
6. [Architecture & Operational Flow](#6-architecture--operational-flow)
7. [response.json Generation Strategy](#7-responsejson-generation-strategy)
8. [IBM COS Upload Integration](#8-ibm-cos-upload-integration)
9. [Logging Framework](#9-logging-framework)
10. [Security Controls](#10-security-controls)
11. [Error Handling](#11-error-handling)
12. [Dependencies](#12-dependencies)
13. [Scheduling](#13-scheduling)
14. [Risks & Considerations](#14-risks--considerations)
15. [Future Enhancements](#15-future-enhancements)
16. [Enterprise Standards Summary](#16-enterprise-standards-summary)
17. [Next Steps](#17-next-steps)
18. [Expected Outcomes](#18-expected-outcomes)

---

## 1. Overview

> **Project Summary**
>
> This document describes the design and implementation of an **enterprise-grade automated backup framework** for MicroStrategy MEP environments. The solution replaces a manual, interactive backup process with a fully automated, secure, and auditable pipeline that uploads validated archives to **IBM Cloud Object Storage (IBM COS)**.

MicroStrategy's native backup utility (`mstrbak`) currently requires manual interaction, making it unsuitable for scheduled, unattended execution in enterprise environments. This framework addresses that gap by:

- Automating end-to-end backup execution via a hardened shell script.
- Dynamically generating the `response.json` configuration consumed by `mstrbak`.
- Uploading validated backup archives to IBM COS using the S3-compatible AWS CLI.
- Enforcing security controls including service accounts, file permissions, and immutable script protection.
- Producing structured, timestamped logs for audit and monitoring purposes.
- Enabling integration with enterprise schedulers such as Ansible AWX, Ansible Tower, and OpenShift CronJob.

---

## 2. Objectives

| # | Objective | Description |
|---|---|---|
| 1 | **Eliminate Manual Interaction** | Remove the need for an operator to interactively respond to `mstrbak` prompts during backup execution. |
| 2 | **Automate Backup Scheduling** | Enable backups to run on a defined schedule (cron or enterprise scheduler) without human intervention. |
| 3 | **Secure Credential Handling** | Manage MSTR, database, and IBM COS credentials securely — avoiding plaintext exposure in scripts or logs. |
| 4 | **Validate Backup Integrity** | Confirm that each backup completes successfully and that the output archive is present before uploading. |
| 5 | **Offsite Storage** | Upload validated backups to IBM Cloud Object Storage for durability, retention management, and disaster recovery readiness. |
| 6 | **Operational Observability** | Maintain structured logs capturing all stages of the backup pipeline for audit, troubleshooting, and compliance. |
| 7 | **Ansible Readiness** | Design the solution to be compatible with Ansible-based orchestration for multi-environment and enterprise-scale deployment. |

---

## 3. Scope

### In Scope

- Automation of MicroStrategy metadata backup using `mstrbak 2.1`.
- Dynamic `response.json` generation via Bash heredoc.
- Backup validation and standardised archive naming.
- Upload to IBM Cloud Object Storage (S3-compatible via AWS CLI).
- Log framework with timestamped, structured entries.
- Security controls: service account ownership, file permissions (`chmod 750`), and immutable file flag (`chattr +i`).
- Local backup retention policy (7-day default).
- Scheduling via `cron` and/or enterprise schedulers (AWX, Tower, OpenShift).
- Error handling with non-zero exit codes for upstream orchestration awareness.

### Out of Scope

- MicroStrategy application-level configuration changes.
- Database schema or data-tier backup (beyond what `mstrbak` captures natively).
- Automated restore / DR testing *(identified as a future enhancement)*.
- Real-time monitoring dashboards (Grafana/Prometheus) *(future enhancement)*.
- Pre-archive encryption *(future enhancement)*.

---

## 4. Existing Environment

### MicroStrategy Component Inventory

| Component | Value | Notes |
|---|---|---|
| MSTR Version | `11.5.1200.0232` | Production release |
| Installation Path | `/opt/` | Base directory for MSTR binaries and configs |
| Server Hostname | `vmserver.example.com` | Host where `mstrbak` is executed |
| Project Source Name | `MSTRJan` | MSTR project source targeted for backup |
| Backup Tool | `mstrbak 2.1` | Native MSTR backup utility |
| Backup Script Path | `/opt/mstrbkc/mstrbak/mstrbkb.sh` | Automation wrapper script |
| Log Directory | `/opt/mstrbkc/mstrbak/` | Centralised log storage |

### Current Backup Process (Baseline)

> **⚠ Warning: Current State — Manual & Interactive**
>
> The current backup process is fully interactive. An operator must be present to respond to each prompt from `mstrbak`. This makes scheduled, unattended execution impossible and introduces risk of human error and inconsistency.

When `./mstrbak` is invoked today, it prompts the operator to supply the following inputs manually:

- MicroStrategy administrator username and password
- Metadata DSN (Data Source Name)
- Database username and password
- Backup scope (full / incremental)
- Output path for the generated archive

---

## 5. Key Features & Requirements

| Feature | Requirement | Priority |
|---|---|---|
| Non-interactive execution | Script must run end-to-end without any operator prompts | Must Have |
| Dynamic response.json generation | Bash heredoc generates JSON config at runtime; no `jq` dependency | Must Have |
| Backup validation | Parse mstrbak log for `finished successfully` string before proceeding | Must Have |
| Standardised archive naming | Format: `<ProjectName>-backup-<hostname>-<YYYY-MM-DD>.tar.gz` | Must Have |
| IBM COS upload | Upload validated archive using `aws s3 cp` with custom endpoint | Must Have |
| Centralised logging | Timestamped log file capturing all stages, outputs, and errors | Must Have |
| Error handling | Non-zero exit on any stage failure; print error message and log path | Must Have |
| Secure credential handling | Passwords not echoed to terminal; not written to logs | Must Have |
| Service account execution | Script runs as dedicated `mstrbackup` account; root execution avoided | Must Have |
| File permission hardening | `chmod 750`, `chown mstrbackup:mstrbackup`, `chattr +i` | Must Have |
| Local retention cleanup | Automatically delete archives older than 7 days from local disk | Should Have |
| Cron scheduling | Daily execution at 02:00 via crontab | Should Have |
| Ansible readiness | Script and parameters designed for Ansible AWX/Tower invocation | Should Have |

---

## 6. Architecture & Operational Flow

> **ℹ Automation Pipeline Overview**
>
> Each step in the pipeline is gated by a validation check. A failure at any stage causes the script to exit with a non-zero code, log the error, and halt further execution — preventing a partial or corrupt backup from being uploaded.

### Stage-by-Stage Breakdown

| Stage | Action | Validation Check |
|---|---|---|
| **1. Input Collection** | Collect project source name, MSTR version, DB type, DSN, credentials, and IBM COS parameters | Required fields must be non-empty; password input is hidden (`-s` flag) |
| **2. Generate response.json** | Write a dynamic JSON configuration file using Bash heredoc containing all mstrbak parameters | Confirm `response.json` file was created and is non-empty |
| **3. Execute mstrbak** | Run `mstrbak -r response.json` in non-interactive mode | Parse mstrbak log for `finished successfully` |
| **4. Validate Backup** | Confirm the generated archive exists on the filesystem | File existence check on the extracted archive path |
| **5. Rename Archive** | Rename archive to standardised format: `<Project>-backup-<host>-<date>.tar.gz` | Confirm renamed file exists |
| **6. Upload to IBM COS** | Execute `aws --endpoint-url s3 cp` to upload the archive to the configured bucket | Check AWS CLI exit code for upload success |
| **7. Retention Cleanup** | Delete local archives older than 7 days using `find ... -mtime +7 -delete` | Log confirmation of deleted files |
| **8. Logging & Monitoring** | Write timestamped log entry covering all stages, outputs, errors, and timings | Log file exists and is non-empty at conclusion |

### Architecture Diagram

```text
┌─────────────────────────────────────────────────┐
│              Scheduler / Ansible AWX             │
│         (Cron: 0 2 * * * / AWX Job Template)    │
└────────────────────┬────────────────────────────┘
                     │ triggers
                     ▼
┌─────────────────────────────────────────────────┐
│          mstrbkb.sh  (Hardened Shell Script)     │
│  Owner: mstrbackup  │  chmod 750  │  chattr +i   │
└────────┬────────────────────────────────────────┘
         │
         ▼
   [1] Collect / Inject Parameters
         │
         ▼
   [2] Generate response.json  (Bash heredoc – no jq)
         │
         ▼
   [3] Execute:  mstrbak -r response.json
         │
         ▼
   [4] Validate:  grep "finished successfully" <log>
         │
         ▼
   [5] Rename Archive
       <Project>-backup-<hostname>-<YYYY-MM-DD>.tar.gz
         │
         ▼
   [6] Upload to IBM COS
       aws --endpoint-url="$ENDPOINT" s3 cp "$FILE" s3://$BUCKET/
         │
         ▼
   [7] Local Retention Cleanup  (find … -mtime +7 -delete)
         │
         ▼
   [8] Write Timestamped Log
       /opt/mstrbkc/mstrbak/backup_YYYY-MM-DD_HH-MM-SS.log
```

---

## 7. response.json Generation Strategy

The `response.json` file is the configuration input that allows `mstrbak` to run in non-interactive mode. Rather than maintaining a static JSON file or patching it with `jq`, the framework generates the file dynamically at runtime using a Bash heredoc.

### Approach Comparison

| Approach | Pros | Cons |
|---|---|---|
| **Static JSON file** | Simple to understand | Credentials embedded at rest; not environment-aware; difficult to rotate secrets |
| **jq-based patching** | JSON-aware manipulation | Requires `jq` binary; complex escaping; harder to troubleshoot |
| **Bash heredoc *(selected)*** | No external dependency; values injected at runtime; portable; easy to audit | No native JSON schema validation (mitigated by validation step) |

### Example Generation Pattern

```bash
cat > /opt/mstrbkc/mstrbak/response.json <<EOF
{
  "projectSourceName": "${PROJECT_SOURCE}",
  "mstrVersion":       "${MSTR_VERSION}",
  "dbType":            "${DB_TYPE}",
  "dsnName":           "${DSN_NAME}",
  "username":          "${MSTR_USER}",
  "password":          "${MSTR_PASS}",
  "outputPath":        "${OUTPUT_PATH}"
}
EOF
```

> **💡 Best Practice**
>
> Credentials passed into the heredoc should be sourced from environment variables or a secrets manager (e.g., HashiCorp Vault, Ansible Vault, or an encrypted credential file), never hardcoded in the script itself. The `response.json` file should be deleted immediately after `mstrbak` completes to avoid credentials persisting on disk.

---

## 8. IBM COS Upload Integration

IBM Cloud Object Storage (IBM COS) is S3-compatible, enabling the use of the standard AWS CLI with a custom endpoint URL. No IBM-specific SDK is required.

### Required Parameters

| Parameter | Environment Variable | Description |
|---|---|---|
| Access Key | `AWS_ACCESS_KEY_ID` | IBM COS HMAC access key |
| Secret Key | `AWS_SECRET_ACCESS_KEY` | IBM COS HMAC secret key |
| Bucket Name | `COS_BUCKET` | Target bucket in IBM COS |
| Endpoint URL | `COS_ENDPOINT` | IBM COS S3-compatible endpoint (e.g., `https://s3.us-south.cloud-object-storage.appdomain.cloud`) |

### Upload Command

```bash
AWS_ACCESS_KEY_ID="${COS_ACCESS_KEY}" \
AWS_SECRET_ACCESS_KEY="${COS_SECRET_KEY}" \
aws --endpoint-url="${COS_ENDPOINT}" \
    s3 cp "${BACKUP_FILE}" "s3://${COS_BUCKET}/"
```

---

## 9. Logging Framework

| Attribute | Value |
|---|---|
| Log Directory | `/opt/mstrbkc/mstrbak/` |
| Log Filename Format | `backup_YYYY-MM-DD_HH-MM-SS.log` |
| Log Scope | Command execution, mstrbak output, upload result, errors, stage timings |
| Retention | Aligned with local archive retention (7-day default; configurable) |

### Log Content Structure

Each log file captures the following sections in order:

1. **Header** – timestamp, hostname, script version, invocation parameters (credentials redacted)
2. **response.json generation** – success/failure
3. **mstrbak execution** – full stdout/stderr output
4. **Validation result** – `finished successfully` found / not found
5. **Archive rename** – original path → new path
6. **IBM COS upload** – AWS CLI output, success/failure
7. **Retention cleanup** – list of deleted files
8. **Footer** – total duration, final exit code

---

## 10. Security Controls

> **⚠ Security Requirements**
>
> All security controls below are mandatory for production deployment. Running the backup script as `root` or with world-readable permissions is not permitted.

| Control | Command | Purpose |
|---|---|---|
| Restrict execution permissions | `chmod 750 mstrbkb.sh` | Owner can execute; group can read/execute; world has no access |
| Assign service account ownership | `chown mstrbackup:mstrbackup mstrbkb.sh` | Script is owned by the dedicated service account, not root |
| Make script immutable | `chattr +i mstrbkb.sh` | Prevents accidental or malicious modification without explicit `chattr -i` removal |
| Hidden password input | `read -s PASSWORD` | Prevents credentials appearing in terminal or log output |
| Credential ephemeral handling | Delete `response.json` after mstrbak execution | Prevents credentials persisting on disk in cleartext |
| Least privilege service account | Dedicated `mstrbackup` OS user with no shell login | Limits blast radius of any compromise to backup operations only |

### Service Account Setup

```bash
# Create service account with no interactive login shell
useradd -r -s /sbin/nologin -d /opt/mstrbkc mstrbackup

# Apply ownership and permissions
chown -R mstrbackup:mstrbackup /opt/mstrbkc/mstrbak/
chmod 750 /opt/mstrbkc/mstrbak/mstrbkb.sh

# Lock script against modification
chattr +i /opt/mstrbkc/mstrbak/mstrbkb.sh
```

---

## 11. Error Handling

The script must implement fail-fast error handling. Every critical operation must be followed by a validation check. On failure, the script must:

1. Print a descriptive error message to stdout and the log file.
2. Print the path to the current log file for operator reference.
3. Exit with a non-zero status code (e.g., `exit 1`) so that the calling scheduler or orchestrator is aware of the failure.

### Validation Checklist

| Validation Point | Check | Failure Action |
|---|---|---|
| Required directories exist | `[ -d "$LOG_DIR" ]` | Create directory or exit with error |
| response.json created | `[ -s response.json ]` | Log error + exit 1 |
| mstrbak execution success | `grep "finished successfully" <log>` | Log error + exit 1 |
| Backup archive exists | `[ -f "$ARCHIVE_PATH" ]` | Log error + exit 1 |
| IBM COS upload success | Check `$?` after `aws s3 cp` | Log error + exit 1 |

---

## 12. Dependencies

| Dependency | Version / Notes | Required For |
|---|---|---|
| `mstrbak` | 2.1 (bundled with MSTR 11.5.1200.0232) | Core backup execution |
| Bash | 4.x or higher | Script runtime; heredoc generation |
| AWS CLI | v2 recommended | IBM COS upload (S3-compatible) |
| `find` | GNU findutils | Local retention cleanup |
| `chattr` | e2fsprogs | Immutable file protection |
| IBM COS HMAC Credentials | Access Key + Secret Key pair | Authentication to IBM COS bucket |
| MicroStrategy Service Account | Admin privileges on project source `MSTRJan` | mstrbak authentication |
| Metadata DSN | Configured ODBC/JDBC DSN on the server | mstrbak metadata database connection |
| Ansible AWX / Tower *(optional)* | Enterprise scheduler | Orchestration and multi-environment scheduling |

---

## 13. Scheduling

### Cron (Simple Scheduling)

```bash
# Run daily MSTR backup at 02:00 AM as the mstrbackup service account
0 2 * * * /opt/mstrbkc/mstrbak/mstrbkb.sh >> /opt/mstrbkc/mstrbak/cron.log 2>&1
```

### Enterprise Scheduler Options

| Scheduler | Use Case | Notes |
|---|---|---|
| **Ansible AWX** | Multi-environment orchestration with approval workflows | Recommended for enterprise; supports credential injection via AWX Credential types |
| **Ansible Tower** | Enterprise licensed version of AWX | Same capabilities as AWX with commercial support and RBAC |
| **OpenShift CronJob** | Container-native scheduling on OpenShift/Kubernetes | Script packaged as a container image; secrets injected via OpenShift Secrets |
| **Linux cron** | Simple, host-local scheduling | Sufficient for single-host deployments; no orchestration overhead |

---

## 14. Risks & Considerations

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Credentials exposed in response.json | Medium | High | Delete response.json immediately after mstrbak execution; restrict directory permissions |
| mstrbak output format changes between versions | Low | High | Pin MSTR version; test validation regex after any MSTR upgrade |
| Disk space exhaustion before upload completes | Medium | High | Pre-flight disk space check; alert on low space; run retention cleanup before backup in future iterations |
| IBM COS endpoint unavailable | Low | Medium | Script exits non-zero; cron or AWX can trigger retry or alert; consider multi-region COS bucket |
| Backup archive corruption | Low | High | Future: checksum validation (MD5/SHA256) before and after upload; automated restore testing |
| Service account credentials compromised | Low | High | Immutable script flag (`chattr +i`); least privilege; periodic credential rotation |
| Cron job silently skipped on host downtime | Medium | Medium | Migrate to AWX/Tower with missed-run alerting for production environments |

---

## 15. Future Enhancements

> **ℹ Roadmap Items**
>
> The following enhancements are out of scope for the initial implementation but are recommended for a full enterprise hardening programme. Prioritise based on organisational risk appetite and compliance requirements.

| Enhancement | Description | Suggested Tool |
|---|---|---|
| **Archive Encryption** | Encrypt `.tar.gz` archives before upload using GPG or openssl to ensure data-at-rest security in IBM COS | GPG, openssl |
| **Checksum Validation** | Generate and verify SHA-256 checksums before and after upload to detect corruption | sha256sum, AWS S3 ETag |
| **Monitoring Dashboard** | Expose backup success/failure metrics for operational visibility | Grafana + Prometheus, or Datadog |
| **Alerting & Notifications** | Send success/failure notifications to operations team | Slack webhook, Teams webhook, SMTP |
| **Automated DR Validation** | Periodically restore a backup into a sandbox environment to confirm recoverability | Ansible playbook, isolated MSTR instance |
| **Multi-Environment Support** | Parameterise the script for DEV, QA, and PROD environments with separate COS buckets and retention policies | Ansible inventory groups, AWX job templates |
| **Secrets Manager Integration** | Replace environment-variable credentials with dynamic secrets fetched at runtime | HashiCorp Vault, IBM Secrets Manager, Ansible Vault |
| **COS Retention Policy** | Configure IBM COS object lifecycle rules for automated tiering and deletion of old backups | IBM COS Lifecycle Configuration |

---

## 16. Enterprise Standards Summary

| Area | Recommended Standard | Rationale |
|---|---|---|
| **Automation** | Bash + response.json (heredoc) | Zero external dependencies; portable; easy to maintain |
| **Orchestration** | Ansible (AWX / Tower) | RBAC, credential injection, audit trail, multi-environment scaling |
| **Storage** | IBM Cloud Object Storage | S3-compatible; durable; geographic redundancy; lifecycle management |
| **Security** | Dedicated service account + immutable script | Least privilege principle; tamper-resistant execution environment |
| **Scheduling** | AWX for enterprise; cron for simple deployments | AWX provides alerting on missed runs; cron is sufficient for single-node |
| **Monitoring** | Log-based validation (phase 1); Grafana/Prometheus (phase 2) | Immediate value from structured logs; metrics dashboards as maturity increases |
| **Scalability** | Template-driven parameterisation | Single script / Ansible playbook deployable to multiple MSTR environments without modification |

---

## 17. Next Steps

> **✅ Implementation Checklist**
>
> Complete the following steps in order to move from design to production operation.

| # | Action Item | Owner | Status |
|---|---|---|---|
| 1 | Create `mstrbackup` OS service account on `vmserver.example.com` | Systems Admin | Pending |
| 2 | Provision IBM COS bucket and generate HMAC credentials | Cloud Ops | Pending |
| 3 | Install and configure AWS CLI v2 on the backup host | Systems Admin | Pending |
| 4 | Develop and unit-test `mstrbkb.sh` in a non-production environment | Developer | Pending |
| 5 | Validate `response.json` format against mstrbak 2.1 schema | Developer / MSTR Admin | Pending |
| 6 | Execute end-to-end backup test in QA environment; confirm archive in IBM COS | Developer / QA | Pending |
| 7 | Apply security hardening (chmod, chown, chattr) | Systems Admin | Pending |
| 8 | Configure cron job or AWX job template for daily 02:00 execution | Systems Admin / DevOps | Pending |
| 9 | Validate log output and retention cleanup after first scheduled run | Operations | Pending |
| 10 | Document runbook for backup failure recovery and manual re-run procedure | Operations | Pending |
| 11 | Schedule post-implementation review (30 days after go-live) | Project Lead | Pending |

---

## 18. Expected Outcomes

Upon successful completion of the implementation, the following operational improvements will be realised:

- **Fully automated backups** — no operator intervention required for routine execution.
- **Standardised archive naming** — consistent, searchable filenames across all backup runs.
- **Offsite durability** — every validated backup uploaded to IBM COS for disaster recovery readiness.
- **Centralised audit logging** — timestamped logs covering every pipeline stage, enabling compliance reporting.
- **Reduced operational overhead** — operations team freed from manual backup tasks; focus shifts to monitoring and exception handling.
- **Improved enterprise compliance** — consistent, auditable, and repeatable backup process aligned to enterprise standards.
- **Scheduler-compatible design** — ready for integration with Ansible AWX, Tower, or OpenShift CronJob without script modification.

---

## Document Control

| Version | Date | Author | Change Summary |
|---|---|---|---|
| 1.0 | 2026-05-07 | Generated from intent_mstr_backup.md | Initial documentation page creation |
