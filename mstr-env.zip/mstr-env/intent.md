# intent.md — MicroStrategy Environment Deployment Knowledge Base

## Objective
Create a professional Confluence page documenting the end-to-end architecture, deployment workflow, operational behavior, and automation flow for MicroStrategy Environment deployment on OpenShift using the MicroStrategy Operator and Ansible automation.

The generated Confluence page should:
- Be enterprise-grade and technically detailed
- Explain architecture and operational flow clearly
- Include lifecycle, reconciliation, automation, and troubleshooting concepts
- Be structured for platform engineers, DevOps engineers, and OpenShift administrators
- Use professional formatting with headings, tables, code blocks, diagrams (where applicable), and workflow sections

---

# Primary Topic
MicroStrategy Environment Deployment using MstrEnvironment CR on OpenShift

---

# Core Concepts to Cover

## 1. MstrEnvironment CR Overview
Explain:
- What the MstrEnvironment Custom Resource (CR) is
- Why declarative deployment is used
- How Kubernetes Operators work
- How the MicroStrategy Operator watches CRs
- Desired state vs actual state reconciliation
- Benefits of operator-based deployment

Important points:
- Single declarative object
- Infrastructure abstraction
- Automated lifecycle management
- Self-healing and reconciliation
- Scalability and consistency

---

# 2. Environment Creation Workflow

Explain the full workflow in sequence:

## Step 1 — Operator Installation
Describe:
- Installation of MicroStrategy Operator
- Namespace usage
- CRD registration
- Operator watch mechanism

Mention:
- Operator watches MstrEnvironment CRs
- Operator reconciliation loop

---

## Step 2 — Define MstrEnvironment CR

Explain:
- YAML definition
- Desired state declaration
- Environment specification

Include:
- Environment name
- Node types
- Intelligence Server
- Web
- Library
- Gateway
- Resource requests/limits
- Storage
- Licensing
- Credentials

Example command:
```bash
oc apply -f mstrenvironment.yaml
```

---

## Step 3 — Apply the CR

Explain:
- What happens after applying CR
- API server registration
- etcd storage
- Operator event trigger

---

## Step 4 — Operator Reconciliation

Explain deeply:
- Reconciliation loop
- Desired state comparison
- Resource creation
- StatefulSets
- Deployments
- Services
- PVCs
- Routes
- ConfigMaps
- Secrets

Mention:
- Continuous reconciliation
- Drift correction
- Automatic remediation

---

## Step 5 — Deployment & Initialization

Explain:
- Pod scheduling
- Container startup
- Service initialization
- Internal communication
- Metadata repository connections
- Licensing initialization

---

## Step 6 — Status Monitoring

Explain:
- CR status updates
- Status phases

Include:
- Pending
- Provisioning
- Running
- Ready
- Failed

Mention:
- oc describe
- oc logs
- Events

---

## Step 7 — Post Deployment Access

Explain:
- OpenShift routes
- External access
- Library UI
- Web UI
- Gateway endpoints

---

# 3. Ansible Automation Workflow (main.yml)

Create a detailed section explaining the automation workflow.

---

## Overall Automation Purpose

Explain:
- End-to-end orchestration
- Idempotent automation
- Environment provisioning
- Validation and auditing

Mention:
- Stage-based execution
- Error handling
- Post-validation

---

# Detailed Workflow Stages

## Login Phase (login.yml)

Explain:
- oc login execution
- Cluster authentication
- Session establishment

Output:
```yaml
step_login: SUCCESS
```

---

## SMOP Validation (validate_smop.yml)

Explain:
- Service Mesh validation
- Operator readiness
- CRD verification
- Permission validation

Outputs:
```yaml
step_amcp: SUCCESS
step_smmr: SUCCESS
```

---

## Namespace Creation (namespace.yml)

Explain:
- Namespace creation
- Project validation
- Labels and annotations

Output:
```yaml
step_namespace: SUCCESS
```

---

## Registry Secret Creation (registry_secret.yml)

Explain:
- Private image registry access
- Docker pull secret
- Service account linkage

---

## Service Mesh Configuration (smmr.yml)

Explain:
- SMMR
- Namespace onboarding
- East-west traffic
- Inter-service communication

Output:
```yaml
step_mesh: SUCCESS
```

---

## Environment Readiness Validation (wait_env.yml)

Explain:
- Pod readiness checks
- Health validation
- Readiness polling

Output:
```yaml
step_ready: SUCCESS
```

---

## Route Creation (route.yml)

Explain:
- OpenShift route exposure
- External accessibility
- TLS and ingress

Output:
```yaml
step_route: SUCCESS
```

---

# 4. Error Handling and Recovery

## Rescue Block

Explain:
- Failure handling
- Execution stop
- Status tracking

Output:
```yaml
playbook_result: FAILED
```

Discuss:
- Enterprise-grade failure control
- Controlled rollback concepts
- Failure visibility

---

# 5. Always Block Operations

Explain:
- Why always block exists
- Post-execution diagnostics
- Audit collection

---

## Pod Status Collection

Command:
```bash
oc get pods -n <namespace>
```

Explain:
- Runtime validation
- Debugging support
- Operational visibility

---

## Component-Level Health Extraction

Explain extraction logic for:
- Intelligence Server
- Library
- Gateway
- Mobile

Possible states:
- Running
- Pending
- Failed
- CrashLoopBackOff

---

## Audit Logging (audit.yml)

Explain:
- Deployment traceability
- Audit records
- Compliance tracking
- Operational reporting

---

## Notification Handling (send_email.yml)

Explain:
- Deployment summary
- Status notification
- Health reporting

Include:
- Step status
- Component status
- Final result

---

# 6. Dynamic Configuration and Customization

Explain:
- Parameterized deployment
- Reusable automation
- Environment abstraction

File location:
```bash
roles/<role_name>/defaults/main.yml
```

---

# Important Variables

## Cluster Details
```yaml
ocp_cluster_name:
ocp_api_url:
ocp_environment:
namespace:
```

---

## Application Configuration
```yaml
application_name:
mstr_environment_type:
mstr_version:
deployment_size:
```

---

## Identity and Access
```yaml
fid_username:
csi_id:
```

---

## Storage Configuration
```yaml
storage_class:
storage_size:
```

---

## Networking
```yaml
base_domain:
route_subdomain:
```

---

## Notification Configuration
```yaml
email_recipients:
```

---

# 7. Sensitive Data Handling

## Ansible Vault

Explain:
- Secret management
- Encryption
- Enterprise security best practices

Example:
```yaml
fid_password: !vault |
  $ANSIBLE_VAULT;1.1;AES256
```

---

## Vault Commands

### Encrypt
```bash
ansible-vault encrypt group_vars/all/vault.yml
```

### Edit
```bash
ansible-vault edit group_vars/all/vault.yml
```

### Run Playbook
```bash
ansible-playbook main.yml --ask-vault-pass
```

---

# 8. Variable Precedence

Explain Ansible variable hierarchy:
1. defaults/main.yml
2. vars/main.yml
3. inventory variables
4. extra vars

Example:
```bash
ansible-playbook main.yml -e "mstr_version=11.3.8 deployment_size=large"
```

---

# 9. Architecture Deep Dive

Generate detailed explanation sections for:
- Operator architecture
- Kubernetes reconciliation loop
- CRD lifecycle
- Stateful vs stateless services
- OpenShift networking
- Service Mesh integration
- Persistent storage handling
- Route exposure
- Internal service communication
- Namespace isolation
- Resource management
- Scaling concepts

---

# 10. Enterprise Operational Best Practices

Include best practices for:
- Production deployments
- HA architecture
- Resource sizing
- Monitoring
- Logging
- Backup strategy
- Disaster recovery
- Security hardening
- Namespace governance
- GitOps integration
- CI/CD integration
- Secret management
- Upgrade planning

---

# 11. Troubleshooting Section

Generate troubleshooting guidance for:
- Pods not starting
- PVC binding failures
- Route accessibility issues
- Image pull failures
- Service mesh issues
- Operator reconciliation failures
- CR stuck in provisioning
- CrashLoopBackOff
- Readiness probe failures

Include useful commands:
```bash
oc get pods
oc describe pod
oc logs
oc get events
oc describe mstrenvironment
```

---

# 12. Expected Output Style

The generated Confluence page should:
- Use professional enterprise tone
- Include structured headings
- Include workflow diagrams (markdown compatible)
- Include YAML examples
- Include command examples
- Include operational notes
- Include architecture explanations
- Include troubleshooting tables
- Be highly detailed and educational

---

# Suggested Confluence Structure

1. Introduction
2. Architecture Overview
3. Operator Workflow
4. MstrEnvironment CR Deep Dive
5. Deployment Lifecycle
6. Ansible Automation Flow
7. Security & Secrets
8. Dynamic Configuration
9. Operational Monitoring
10. Troubleshooting
11. Best Practices
12. Conclusion

---

# Important Instructions for Claude

While generating the Confluence page:
- Expand all concepts deeply
- Add technical explanations
- Add enterprise operational context
- Maintain professional formatting
- Avoid shallow summaries
- Use OpenShift/Kubernetes terminology correctly
- Add real-world operational insights
- Explain WHY each step exists
- Explain HOW reconciliation works internally
- Include production-grade recommendations

---

# Source Reference

This intent file was generated from the uploaded MicroStrategy Environment deployment overview document and operational workflow notes.
