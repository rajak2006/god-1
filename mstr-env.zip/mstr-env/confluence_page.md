# MicroStrategy Environment Deployment on OpenShift — Platform Engineering Reference

**Document Type:** Platform Engineering Reference  
**Audience:** Platform Engineers, DevOps Engineers, OpenShift Administrators  
**Status:** Active  
**Topic:** MicroStrategy Operator-Based Deployment using MstrEnvironment CR and Ansible Automation

---

## Table of Contents

1. [Introduction](#1-introduction)
2. [Architecture Overview](#2-architecture-overview)
3. [Operator Workflow](#3-operator-workflow)
4. [MstrEnvironment CR Deep Dive](#4-mstrenvironment-cr-deep-dive)
5. [Deployment Lifecycle](#5-deployment-lifecycle)
6. [Ansible Automation Flow](#6-ansible-automation-flow)
7. [Security and Secrets Management](#7-security-and-secrets-management)
8. [Dynamic Configuration](#8-dynamic-configuration)
9. [Operational Monitoring](#9-operational-monitoring)
10. [Troubleshooting](#10-troubleshooting)
11. [Enterprise Best Practices](#11-enterprise-best-practices)
12. [Conclusion](#12-conclusion)

---

## 1. Introduction

### Overview

This document provides a comprehensive reference for deploying and managing **MicroStrategy environments on Red Hat OpenShift** using the **MicroStrategy Kubernetes Operator** and **Ansible automation**. It covers the full deployment lifecycle — from operator installation through environment readiness — and serves as the authoritative operational guide for platform teams responsible for provisioning, maintaining, and troubleshooting MicroStrategy deployments in enterprise OpenShift clusters.

### What is MicroStrategy on OpenShift?

MicroStrategy is an enterprise business intelligence and analytics platform. When deployed on OpenShift, it runs as a collection of containerized services managed through Kubernetes primitives. Rather than deploying each service independently through manual YAML manifests, the **MicroStrategy Operator** abstracts the entire platform into a single, declarative **Custom Resource (CR)** — the `MstrEnvironment`.

This approach brings the full power of Kubernetes-native lifecycle management — including automated provisioning, self-healing, rolling updates, and state reconciliation — to MicroStrategy deployments.

### Why Operator-Based Deployment?

| Traditional Deployment | Operator-Based Deployment |
|---|---|
| Manual YAML for each component | Single `MstrEnvironment` CR |
| No automatic self-healing | Continuous reconciliation loop |
| Prone to configuration drift | Drift detection and automatic remediation |
| Manual upgrade coordination | Operator-managed lifecycle events |
| Hard to replicate environments | Parameterized, reproducible deployments |
| No built-in status tracking | Rich status phases and events |

The MicroStrategy Operator encapsulates years of operational knowledge into automated control loops, reducing human error and enabling consistent deployments across development, staging, and production environments.

---

## 2. Architecture Overview

### High-Level Architecture

```
+----------------------------------------------------------+
|                   OpenShift Cluster                       |
|                                                          |
|  +------------------+     +---------------------------+  |
|  | MicroStrategy    |     |  MstrEnvironment CR        |  |
|  | Operator Pod     |<--->|  (Desired State)           |  |
|  | (Control Plane)  |     +---------------------------+  |
|  +--------+---------+                                    |
|           |                                              |
|           | Reconciliation Loop                          |
|           v                                              |
|  +----------------------------------------------------------+
|  |              MicroStrategy Namespace                    |
|  |                                                        |
|  |  +----------------+  +----------------+               |
|  |  | Intelligence   |  | MicroStrategy  |               |
|  |  | Server (IS)    |  | Web (MSTRWeb)  |               |
|  |  | StatefulSet    |  | Deployment     |               |
|  |  +----------------+  +----------------+               |
|  |                                                        |
|  |  +----------------+  +----------------+               |
|  |  | Library        |  | Gateway        |               |
|  |  | Deployment     |  | Deployment     |               |
|  |  +----------------+  +----------------+               |
|  |                                                        |
|  |  +----------------+  +----------------+               |
|  |  | PersistentVol- |  | OpenShift      |               |
|  |  | umeClaims      |  | Routes         |               |
|  |  +----------------+  +----------------+               |
|  +----------------------------------------------------------+
|                                                          |
|  +----------------------------------------------------------+
|  |             OpenShift Service Mesh (Istio)             |
|  |  East-West Traffic Management | mTLS | Observability  |
|  +----------------------------------------------------------+
+----------------------------------------------------------+
```

### Component Roles

| Component | Type | Role |
|---|---|---|
| **MicroStrategy Operator** | Controller Pod | Watches and reconciles `MstrEnvironment` CRs |
| **Intelligence Server (IS)** | StatefulSet | Core analytics engine and metadata repository manager |
| **MicroStrategy Web** | Deployment | Browser-based report and dashboard delivery |
| **Library** | Deployment | Modern MicroStrategy Library application (REST API + UI) |
| **Gateway** | Deployment | API gateway layer for routing client requests |
| **Metadata Repository** | External DB | Backend relational database (e.g., PostgreSQL, MS SQL) |
| **PersistentVolumeClaims** | Storage | Durable storage for IS data, logs, and configurations |
| **OpenShift Routes** | Networking | External ingress endpoints for Library, Web, and Gateway |
| **Service Mesh (SMMR)** | Infrastructure | East-west mTLS, traffic management, service discovery |

### Kubernetes Operator Pattern

The MicroStrategy Operator implements the **Kubernetes Operator Pattern** — a method of packaging, deploying, and managing an application using Kubernetes APIs and custom controllers.

```
Desired State (MstrEnvironment CR)
         |
         v
  +-------------------+
  | Operator Controller|
  | - Watch Events     |
  | - Compare States   |
  | - Act on Diff      |
  +-------------------+
         |
         v
  Actual State (Running Resources)
```

The operator continuously runs a **reconciliation loop**:
1. **Observe** — Read the current state of the cluster
2. **Analyze** — Compare current state against the desired state in the CR
3. **Act** — Create, update, or delete resources to converge toward desired state

This loop runs continuously, ensuring that any manual changes, node failures, or configuration drift are automatically corrected.

---

## 3. Operator Workflow

### Step 1 — Operator Installation

Before any MicroStrategy environment can be deployed, the MicroStrategy Operator must be installed in the OpenShift cluster. This is typically a one-time setup activity performed by a cluster administrator.

**What Happens During Operator Installation:**

1. **Custom Resource Definition (CRD) Registration** — The `MstrEnvironment` CRD is registered with the Kubernetes API server, extending it with MicroStrategy-specific resource types.
2. **Operator Deployment** — The operator's controller pod is deployed into a dedicated namespace (e.g., `mstr-operator`).
3. **RBAC Configuration** — ClusterRoles and ClusterRoleBindings are created to grant the operator permission to manage resources across target namespaces.
4. **Watch Establishment** — The operator begins watching for `MstrEnvironment` CR events (create, update, delete) across all permitted namespaces.

**Verification Commands:**

```bash
# Verify operator is running
oc get pods -n mstr-operator

# Verify CRD is registered
oc get crd mstrenvironments.mstr.microstrategy.com

# Check operator logs
oc logs -n mstr-operator deployment/mstr-operator -f
```

> **Note:** The operator namespace and deployment name may vary based on your installation method (OLM, Helm, or manual). Consult your MicroStrategy installation guide for the exact values.

---

### Step 2 — Define the MstrEnvironment CR

The `MstrEnvironment` Custom Resource is the **single declarative object** that defines the entire desired state of a MicroStrategy deployment. Platform engineers author this YAML manifest to specify every aspect of the environment.

**Key Specification Sections:**

| Section | Purpose |
|---|---|
| `metadata.name` | Unique identifier for this environment |
| `spec.environmentType` | Edition of MicroStrategy (e.g., Platform, Analytics) |
| `spec.version` | MicroStrategy product version |
| `spec.deploymentSize` | T-shirt sizing (small, medium, large, xlarge) |
| `spec.intelligenceServer` | IS replicas, resource requests/limits |
| `spec.web` | Web tier configuration |
| `spec.library` | Library application configuration |
| `spec.gateway` | Gateway service configuration |
| `spec.storage` | Storage class and volume size |
| `spec.licensing` | License key or license server reference |
| `spec.credentials` | Connection credentials (via Secrets) |

**Example Manifest Structure:**

```yaml
apiVersion: mstr.microstrategy.com/v1
kind: MstrEnvironment
metadata:
  name: mstr-prod-env
  namespace: mstr-production
spec:
  version: "11.3.8"
  deploymentSize: medium
  intelligenceServer:
    replicas: 2
    resources:
      requests:
        cpu: "2"
        memory: "8Gi"
      limits:
        cpu: "4"
        memory: "16Gi"
  library:
    replicas: 2
  web:
    replicas: 2
  gateway:
    replicas: 1
  storage:
    storageClass: gp2
    size: 100Gi
  licensing:
    secretRef: mstr-license-secret
  credentials:
    secretRef: mstr-db-credentials
```

**Apply the CR:**

```bash
oc apply -f mstrenvironment.yaml
```

---

### Step 3 — CR Application and API Server Processing

When `oc apply -f mstrenvironment.yaml` is executed, the following internal Kubernetes process occurs:

1. **API Server Validation** — The Kubernetes API server validates the CR against the registered CRD schema.
2. **Admission Webhooks** — Any configured admission webhooks (MutatingAdmissionWebhook or ValidatingAdmissionWebhook) process the object.
3. **etcd Storage** — The validated CR object is persisted to etcd, the cluster's distributed key-value store.
4. **Operator Event Trigger** — The operator's watch mechanism detects the new CR object via a list-watch on the API server and enqueues a reconciliation request.

> **Why etcd matters:** The CR stored in etcd IS the source of truth for desired state. Even if the operator pod restarts, it will re-read etcd and resume reconciliation from the correct desired state.

---

### Step 4 — Operator Reconciliation Loop (Deep Dive)

The reconciliation loop is the heart of the operator pattern. Upon receiving a reconciliation request, the MicroStrategy Operator performs the following actions:

#### 4.1 State Comparison

The operator fetches the current `MstrEnvironment` CR (desired state) and inventories all currently existing resources in the target namespace (actual state). It computes a diff between these two states.

#### 4.2 Resource Creation / Modification

Based on the diff, the operator creates or updates Kubernetes resources:

| Resource Type | Purpose |
|---|---|
| **StatefulSet** (Intelligence Server) | Manages IS pods with stable network identity and persistent storage |
| **Deployments** (Web, Library, Gateway) | Manages stateless application pods with rolling update support |
| **Services** (ClusterIP) | Internal DNS-based service discovery between components |
| **PersistentVolumeClaims** | Requests durable storage for IS data files and metadata |
| **Routes** | Exposes services externally via OpenShift ingress controller |
| **ConfigMaps** | Stores non-sensitive configuration (server settings, environment vars) |
| **Secrets** | Stores sensitive configuration (credentials, license keys, TLS certs) |
| **ServiceAccounts** | Provides pod identity for RBAC and service mesh interaction |

#### 4.3 Continuous Reconciliation and Drift Correction

The operator does not reconcile once and stop. It continuously monitors the cluster state and re-reconciles whenever:
- A resource is manually modified or deleted
- A pod crashes and restarts
- A new version is available
- The CR spec is updated

**Example: Drift Correction in Action**

```
Scenario: An operator manually deletes the Library deployment

1. Operator detects: Library Deployment is missing (actual state != desired state)
2. Operator re-creates: Library Deployment with spec from CR
3. Result: Environment returns to desired state automatically
```

This self-healing behavior is fundamental to production reliability.

---

### Step 5 — Deployment and Initialization

After the operator creates the Kubernetes resources, the platform orchestrates the actual workload startup:

1. **Pod Scheduling** — The Kubernetes scheduler assigns pods to nodes based on resource requests, node selectors, affinity rules, and taints/tolerations.
2. **Image Pull** — Nodes pull MicroStrategy container images from the configured registry (requires registry pull secret).
3. **Container Startup** — Init containers run first (e.g., database schema validation), followed by main application containers.
4. **Service Initialization** — Intelligence Server initializes its metadata repository connection, loads project configurations, and starts the analytics engine.
5. **Internal Communication** — Components communicate via ClusterIP services using Kubernetes DNS (e.g., `intelligence-server.mstr-production.svc.cluster.local`).
6. **Licensing Initialization** — IS validates licensing against the configured license server or static license key.
7. **Readiness Gates** — Each pod exposes readiness probes that the kubelet polls. Traffic is only routed to pods that pass readiness checks.

---

### Step 6 — Status Monitoring

The MicroStrategy Operator continuously updates the `MstrEnvironment` CR's status subresource to reflect deployment progress. This allows operators to track state without inspecting individual pods.

**CR Status Phases:**

| Phase | Meaning |
|---|---|
| `Pending` | CR received; operator has not yet begun resource creation |
| `Provisioning` | Operator is actively creating and configuring resources |
| `Initializing` | All pods are scheduled; services are starting up |
| `Running` | Services are operational; readiness checks in progress |
| `Ready` | All components pass readiness probes; environment is fully operational |
| `Failed` | A critical error has occurred; manual intervention may be required |
| `Upgrading` | A version update is in progress |

**Monitoring Commands:**

```bash
# View CR status and phase
oc describe mstrenvironment mstr-prod-env -n mstr-production

# Watch pod startup
oc get pods -n mstr-production -w

# View operator events for this environment
oc get events -n mstr-production --sort-by='.lastTimestamp'

# Tail operator logs
oc logs -n mstr-operator deployment/mstr-operator -f

# Check component logs
oc logs -n mstr-production <pod-name> -c <container-name>
```

---

### Step 7 — Post-Deployment Access

Once the environment reaches `Ready` status, external access is available via OpenShift Routes.

| Service | Route Pattern | Protocol |
|---|---|---|
| Library UI | `https://library.<namespace>.<base-domain>` | HTTPS |
| MicroStrategy Web | `https://mstrweb.<namespace>.<base-domain>` | HTTPS |
| Gateway API | `https://gateway.<namespace>.<base-domain>` | HTTPS/REST |
| Intelligence Server | Internal only (ClusterIP) | TCP/MSTR protocol |

> **Note:** Routes are managed by the OpenShift ingress controller and may use Let's Encrypt, your enterprise PKI, or a wildcard TLS certificate depending on cluster configuration.

---

## 4. MstrEnvironment CR Deep Dive

### Why a Custom Resource?

The `MstrEnvironment` CR is an extension of the Kubernetes API. Instead of knowing how to deploy 20+ individual Kubernetes objects, platform engineers interact with a single high-level abstraction purpose-built for MicroStrategy.

**Benefits of CRD-Based Abstraction:**

- **Infrastructure Abstraction** — Engineers declare *what* they want, not *how* to build it.
- **Validation** — The CRD schema enforces valid configurations at apply time.
- **Discoverability** — `oc explain mstrenvironment.spec` provides inline documentation.
- **GitOps Compatibility** — CRs are version-controlled alongside application code.
- **Auditability** — All changes to desired state are captured in git history and etcd audit logs.

### CR Specification Reference

```yaml
apiVersion: mstr.microstrategy.com/v1
kind: MstrEnvironment
metadata:
  name: <environment-name>        # Unique name within the namespace
  namespace: <target-namespace>   # Target deployment namespace
  labels:
    environment: production       # Organizational labels
    team: platform-engineering
spec:
  # -----------------------------------------------
  # Core Environment Settings
  # -----------------------------------------------
  version: "11.3.8"               # MicroStrategy product version
  environmentType: "platform"     # platform | analytics
  deploymentSize: "medium"        # small | medium | large | xlarge

  # -----------------------------------------------
  # Intelligence Server
  # -----------------------------------------------
  intelligenceServer:
    replicas: 2
    resources:
      requests:
        cpu: "2"
        memory: "8Gi"
      limits:
        cpu: "4"
        memory: "16Gi"

  # -----------------------------------------------
  # Web Tier
  # -----------------------------------------------
  web:
    replicas: 2
    resources:
      requests:
        cpu: "500m"
        memory: "2Gi"

  # -----------------------------------------------
  # Library Application
  # -----------------------------------------------
  library:
    replicas: 2

  # -----------------------------------------------
  # Gateway
  # -----------------------------------------------
  gateway:
    replicas: 1

  # -----------------------------------------------
  # Storage
  # -----------------------------------------------
  storage:
    storageClass: "gp2"
    size: "100Gi"

  # -----------------------------------------------
  # Licensing
  # -----------------------------------------------
  licensing:
    secretRef: "mstr-license-secret"

  # -----------------------------------------------
  # Credentials
  # -----------------------------------------------
  credentials:
    secretRef: "mstr-db-credentials"
```

---

## 5. Deployment Lifecycle

### Full Lifecycle State Machine

```
[CR Applied]
     |
     v
[Pending] --> [Provisioning] --> [Initializing] --> [Running] --> [Ready]
     |               |                                               |
     |           [Failed] <----- Error at any phase ----------------+
     |
     v
[Deleted] --> [Terminating] --> [Resources Cleaned Up]
```

### Lifecycle Events

| Event | Trigger | Operator Action |
|---|---|---|
| **Create** | `oc apply` with new CR | Full provisioning of all resources |
| **Update** | `oc apply` with modified CR | Rolling update of affected components |
| **Scale** | Replica count change in CR | Scale StatefulSets / Deployments |
| **Upgrade** | Version change in CR | Coordinated rolling upgrade |
| **Delete** | `oc delete mstrenvironment` | Graceful teardown of all managed resources |

---

## 6. Ansible Automation Flow

### Overview

The Ansible automation (`main.yml`) provides **end-to-end orchestration** of the MicroStrategy deployment process. It is designed to be **idempotent** — running the playbook multiple times produces the same result, making it safe for reruns, pipelines, and disaster recovery scenarios.

The automation is structured as a series of **named stages**, each responsible for a discrete phase of the deployment. Each stage produces a structured output variable (e.g., `step_login: SUCCESS`) that is collected, evaluated, and ultimately included in the deployment audit trail and notification.

### Automation Architecture

```
main.yml
  |
  +-- [Block: Main Execution]
  |     |
  |     +-- login.yml          # Cluster authentication
  |     +-- validate_smop.yml  # Service Mesh / Operator validation
  |     +-- namespace.yml      # Namespace provisioning
  |     +-- registry_secret.yml # Image pull secret
  |     +-- smmr.yml           # Service Mesh Member Roll
  |     +-- apply_cr.yml       # Apply MstrEnvironment CR
  |     +-- wait_env.yml       # Wait for environment readiness
  |     +-- route.yml          # Expose external routes
  |
  +-- [Rescue: Error Handling]
  |     |
  |     +-- Set playbook_result: FAILED
  |     +-- Capture failure context
  |
  +-- [Always: Post-Execution]
        |
        +-- oc get pods (runtime validation)
        +-- Extract component health
        +-- audit.yml          # Write audit record
        +-- send_email.yml     # Send notification
```

---

### Stage 1 — Login Phase (`login.yml`)

**Purpose:** Authenticate to the OpenShift cluster and establish a valid session for all subsequent `oc` commands.

**Why This Step Exists:** All Kubernetes API operations require a valid authentication token. This stage performs `oc login` using the configured API URL and credentials, ensuring the automation context has the permissions required for the subsequent stages.

**What Happens:**
- Executes `oc login --server=<ocp_api_url>` with service account credentials or token.
- Validates that the login was successful.
- Sets the active project context if required.

**Output:**
```yaml
step_login: SUCCESS
```

**Failure Impact:** If login fails, the entire playbook halts immediately. All subsequent stages depend on a valid cluster session.

---

### Stage 2 — Service Mesh / Operator Validation (`validate_smop.yml`)

**Purpose:** Verify that the OpenShift Service Mesh (OSSM / Istio) and MicroStrategy Operator are installed and ready before proceeding with deployment.

**Why This Step Exists:** Deploying a MicroStrategy environment into a cluster without a functioning service mesh or without the operator installed will result in a broken deployment. This validation gate catches misconfigurations early.

**What Is Validated:**
- **AMCP (Adaptive Mesh Control Plane):** Verifies the Istio control plane is healthy and operational.
- **SMMR (ServiceMeshMemberRoll):** Confirms the service mesh member roll controller is ready.
- **CRD Verification:** Confirms `MstrEnvironment` CRD is registered.
- **RBAC Permissions:** Validates the service account has required permissions.

**Outputs:**
```yaml
step_amcp: SUCCESS
step_smmr: SUCCESS
```

---

### Stage 3 — Namespace Creation (`namespace.yml`)

**Purpose:** Provision the target OpenShift namespace (project) for the MicroStrategy environment.

**Why This Step Exists:** Kubernetes namespaces provide the isolation boundary for all environment resources. This stage ensures the namespace exists with the correct labels and annotations before any resources are created.

**What Happens:**
- Creates the namespace if it does not exist (idempotent — no action if already present).
- Applies organizational labels (e.g., `team`, `environment`, `cost-center`).
- Applies annotations required for service mesh integration.
- Validates namespace status.

**Output:**
```yaml
step_namespace: SUCCESS
```

---

### Stage 4 — Registry Secret Creation (`registry_secret.yml`)

**Purpose:** Create a Docker pull secret in the target namespace to allow pods to pull MicroStrategy container images from a private registry.

**Why This Step Exists:** MicroStrategy container images are hosted in a private registry that requires authentication. Without a valid pull secret linked to the default service account, pods will fail to start with `ImagePullBackOff` errors.

**What Happens:**
- Creates a Kubernetes `Secret` of type `kubernetes.io/dockerconfigjson` in the target namespace.
- Links the secret to the `default` and `builder` service accounts using `oc secrets link`.
- Validates the secret is present and correctly formatted.

> **Security Note:** Registry credentials are stored in Ansible Vault and are never logged or exposed in playbook output.

---

### Stage 5 — Service Mesh Configuration (`smmr.yml`)

**Purpose:** Onboard the target namespace into the OpenShift Service Mesh by adding it to the `ServiceMeshMemberRoll` (SMMR).

**Why This Step Exists:** OpenShift Service Mesh (Istio) only manages namespaces explicitly listed in the SMMR. Without this step, MicroStrategy pods will not have Envoy sidecar proxies injected, and east-west mTLS and traffic management will not function.

**What Happens:**
- Patches the `ServiceMeshMemberRoll` object to include the target namespace.
- Waits for the namespace to show `Configured` status in the SMMR.
- Validates that sidecar injection is enabled for the namespace.

**Key Concepts:**
- **East-West Traffic:** Service-to-service communication within the mesh, encrypted with mutual TLS (mTLS).
- **Sidecar Injection:** An Envoy proxy container is automatically injected into every pod, enabling mesh observability and policy enforcement without application code changes.

**Output:**
```yaml
step_mesh: SUCCESS
```

---

### Stage 6 — Environment Readiness Validation (`wait_env.yml`)

**Purpose:** Poll the environment until all MicroStrategy components are running and healthy.

**Why This Step Exists:** The MstrEnvironment CR is applied asynchronously — the operator creates resources and pods start up over time. This stage implements a structured readiness polling loop that waits for the deployment to stabilize before proceeding.

**What Happens:**
- Polls `oc get pods -n <namespace>` on a configurable interval.
- Evaluates pod status for each component (IS, Web, Library, Gateway).
- Checks the `MstrEnvironment` CR status phase.
- Proceeds when all pods are `Running` and `Ready`, and CR phase is `Ready`.
- Fails with a timeout error if readiness is not achieved within the configured window.

**Output:**
```yaml
step_ready: SUCCESS
```

---

### Stage 7 — Route Creation (`route.yml`)

**Purpose:** Create OpenShift Routes to expose MicroStrategy services externally.

**Why This Step Exists:** By default, MicroStrategy services are only accessible within the cluster via ClusterIP services. Routes provide externally accessible HTTPS endpoints through the OpenShift ingress controller.

**What Happens:**
- Creates OpenShift `Route` objects for Library, Web, and Gateway services.
- Configures TLS termination (edge, passthrough, or re-encrypt based on configuration).
- Sets the hostname based on the configured `base_domain` and `route_subdomain` variables.
- Validates route is accessible and returns HTTP 200.

**Output:**
```yaml
step_route: SUCCESS
```

---

## 7. Security and Secrets Management

### Ansible Vault for Secret Encryption

All sensitive configuration values — database passwords, registry credentials, license keys, and API tokens — are encrypted using **Ansible Vault** before being committed to source control.

**Why Ansible Vault?**
- Secrets are never stored in plaintext in Git repositories.
- Vault-encrypted files are safe to commit alongside playbook code.
- Decryption happens at runtime using a vault password provided via CI/CD pipeline secrets or interactive prompt.

**Vault-Encrypted Variable Example:**

```yaml
# group_vars/all/vault.yml
fid_password: !vault |
  $ANSIBLE_VAULT;1.1;AES256
  61386334373932663437373439393930303462386636373462383064
  6130353961626230313136313236306365353738643731390a323839
  ...
```

### Vault Operations Reference

| Operation | Command |
|---|---|
| Encrypt a file | `ansible-vault encrypt group_vars/all/vault.yml` |
| Decrypt a file | `ansible-vault decrypt group_vars/all/vault.yml` |
| Edit encrypted file | `ansible-vault edit group_vars/all/vault.yml` |
| View encrypted file | `ansible-vault view group_vars/all/vault.yml` |
| Re-key vault file | `ansible-vault rekey group_vars/all/vault.yml` |

### Running the Playbook with Vault

```bash
# Interactive vault password prompt
ansible-playbook main.yml --ask-vault-pass

# Using a vault password file (for CI/CD pipelines)
ansible-playbook main.yml --vault-password-file /path/to/vault-pass-file

# Using an environment variable (recommended for pipelines)
ANSIBLE_VAULT_PASSWORD_FILE=/secrets/vault-pass ansible-playbook main.yml
```

### Kubernetes Secret Management

Beyond Ansible Vault, secrets are stored in Kubernetes `Secret` objects within the target namespace:

| Secret | Type | Contents |
|---|---|---|
| `mstr-db-credentials` | Opaque | Database username, password, host, port |
| `mstr-license-secret` | Opaque | MicroStrategy license key |
| `mstr-registry-pull-secret` | `kubernetes.io/dockerconfigjson` | Container registry credentials |
| `mstr-tls-cert` | `kubernetes.io/tls` | TLS certificate and key for routes |

> **Security Recommendation:** Integrate with OpenShift's External Secrets Operator or HashiCorp Vault for production deployments to avoid storing secrets as Kubernetes Secret objects, which are only base64-encoded (not encrypted) by default unless etcd encryption at rest is enabled.

---

## 8. Dynamic Configuration

### Parameterized Deployments

The Ansible automation is designed to be fully parameterized, enabling the same codebase to deploy environments across multiple clusters, namespaces, and configurations without code changes. All environment-specific values are externalized into role default variables.

**Default Variable Location:**
```bash
roles/<role_name>/defaults/main.yml
```

### Variable Reference

#### Cluster Details

```yaml
ocp_cluster_name: "prod-cluster-01"    # Logical cluster identifier
ocp_api_url: "https://api.cluster.example.com:6443"  # OpenShift API endpoint
ocp_environment: "production"           # Environment tier (dev/staging/production)
namespace: "mstr-production"            # Target namespace
```

#### Application Configuration

```yaml
application_name: "mstr-prod-env"      # MstrEnvironment CR name
mstr_environment_type: "platform"       # MicroStrategy edition
mstr_version: "11.3.8"                 # Product version
deployment_size: "medium"              # Resource sizing tier
```

#### Identity and Access

```yaml
fid_username: "svc-mstr-deploy"        # Service account for OpenShift login
csi_id: "CSI-12345"                    # Change record ID for audit compliance
```

#### Storage Configuration

```yaml
storage_class: "gp2"                   # StorageClass name in the cluster
storage_size: "100Gi"                  # PVC capacity request
```

#### Networking

```yaml
base_domain: "apps.cluster.example.com"   # OpenShift wildcard domain
route_subdomain: "mstr-prod"              # Route hostname prefix
```

#### Notification Configuration

```yaml
email_recipients:
  - "platform-team@company.com"
  - "mstr-admins@company.com"
```

### Ansible Variable Precedence

Ansible resolves variables in the following priority order (lowest to highest):

| Priority | Source | Use Case |
|---|---|---|
| 1 (Lowest) | `roles/<role>/defaults/main.yml` | Default values — safe fallbacks |
| 2 | `roles/<role>/vars/main.yml` | Role-level overrides |
| 3 | Inventory variables (`host_vars/`, `group_vars/`) | Environment-specific values |
| 4 (Highest) | Extra vars (`-e` flag) | Runtime overrides for one-off deployments |

**Runtime Override Example:**

```bash
# Deploy a specific version at large scale
ansible-playbook main.yml \
  --vault-password-file /secrets/vault-pass \
  -e "mstr_version=11.3.9 deployment_size=large namespace=mstr-prod-v2"
```

---

## 9. Operational Monitoring

### Error Handling — Rescue Block

The main Ansible playbook wraps the core execution stages in a `block/rescue/always` structure. If any stage fails, the rescue block captures the failure state and prevents uncontrolled propagation.

**Rescue Block Behavior:**
1. Sets `playbook_result: FAILED`
2. Records the failing stage and error message
3. Halts further execution of the main workflow
4. Passes control to the `always` block for post-execution tasks (diagnostics, audit, notification)

```yaml
playbook_result: FAILED
```

**Why This Matters:** Without structured error handling, a failure in an intermediate stage (e.g., service mesh configuration) could leave the cluster in a partially provisioned state. The rescue block ensures that failures are visible, logged, and communicated — enabling rapid diagnosis and remediation.

---

### Always Block — Post-Execution Diagnostics

Regardless of playbook success or failure, the `always` block executes to collect runtime diagnostics, write audit records, and send notifications.

#### Pod Status Collection

```bash
oc get pods -n <namespace>
```

This command is executed unconditionally and captures the final pod state at playbook completion. The output is parsed and stored for health reporting.

#### Component-Level Health Extraction

The automation extracts the status of each individual MicroStrategy component pod:

| Component | Possible States |
|---|---|
| Intelligence Server | `Running`, `Pending`, `CrashLoopBackOff`, `Failed`, `Terminating` |
| Library | `Running`, `Pending`, `CrashLoopBackOff`, `Failed` |
| Gateway | `Running`, `Pending`, `CrashLoopBackOff`, `Failed` |
| Web | `Running`, `Pending`, `CrashLoopBackOff`, `Failed` |
| Mobile (if applicable) | `Running`, `Pending`, `CrashLoopBackOff`, `Failed` |

---

### Audit Logging (`audit.yml`)

**Purpose:** Write a structured audit record for every playbook execution — success or failure.

**Why Auditing Matters:**
- **Compliance:** Enterprise environments require traceability of all infrastructure changes.
- **Incident Investigation:** Audit logs provide the deployment history needed to diagnose post-deployment issues.
- **Change Management:** Audit records map deployment events to change tickets (via `csi_id`).
- **Reporting:** Operations teams can report on deployment frequency, success rates, and durations.

**Audit Record Contents:**
- Timestamp
- Operator identity (`fid_username`)
- Change ticket (`csi_id`)
- Target cluster and namespace
- MicroStrategy version deployed
- Stage-by-stage step outcomes
- Component health summary
- Final playbook result (`SUCCESS` / `FAILED`)

---

### Notification Handling (`send_email.yml`)

**Purpose:** Send a deployment summary email to configured recipients at the conclusion of every playbook run.

**Email Content:**

| Section | Content |
|---|---|
| Deployment Summary | Cluster, namespace, version, timestamp |
| Step Status | Pass/fail for each automation stage |
| Component Health | Per-component pod status |
| Final Result | `SUCCESS` or `FAILED` with failure reason |
| Links | Route URLs for accessing the deployed environment |

**Notification Flow:**
```
Always Block
    |
    +-- Collect step statuses (step_login, step_amcp, ...)
    +-- Collect component health (IS, Library, Gateway, Web)
    +-- Assemble email body from template
    +-- Send via SMTP relay
```

---

## 10. Troubleshooting

### Common Issues and Resolutions

#### Issue: Pods Not Starting / Stuck in Pending

| Symptom | Likely Cause | Resolution |
|---|---|---|
| Pod status `Pending` for > 5 min | Insufficient cluster resources | Check node capacity: `oc describe nodes` |
| Pod status `Pending` — no node matching | Node affinity / taint mismatch | Review CR resource requests vs. available nodes |
| Pod status `Pending` — PVC unbound | StorageClass misconfiguration | Check PVC: `oc describe pvc -n <namespace>` |

```bash
# Check pod events for scheduling failures
oc describe pod <pod-name> -n <namespace>

# Check node available resources
oc describe nodes | grep -A 5 "Allocated resources"
```

---

#### Issue: PVC Binding Failures

| Symptom | Likely Cause | Resolution |
|---|---|---|
| PVC status `Pending` | StorageClass does not exist | Verify: `oc get storageclass` |
| PVC status `Pending` | No matching PersistentVolume | Check available PVs: `oc get pv` |
| PVC status `Lost` | Underlying storage backend issue | Contact storage team; may require PV reclamation |

```bash
# Inspect PVC details
oc describe pvc -n <namespace>

# List available storage classes
oc get storageclass
```

---

#### Issue: Route Not Accessible

| Symptom | Likely Cause | Resolution |
|---|---|---|
| HTTPS returns connection refused | Route not created | Verify: `oc get routes -n <namespace>` |
| Certificate error | TLS secret missing or expired | Inspect: `oc get secret mstr-tls-cert -n <namespace>` |
| 503 Service Unavailable | Pods not ready | Check pod readiness: `oc get pods -n <namespace>` |
| DNS not resolving | Wildcard DNS misconfiguration | Verify base_domain resolves to ingress VIP |

```bash
# List routes and their hostnames
oc get routes -n <namespace>

# Test route accessibility
curl -k -I https://library.<namespace>.<base-domain>
```

---

#### Issue: Image Pull Failures (`ImagePullBackOff`)

| Symptom | Likely Cause | Resolution |
|---|---|---|
| `ImagePullBackOff` | Registry pull secret missing | Run `registry_secret.yml` stage manually |
| `ImagePullBackOff` | Incorrect registry URL | Verify `registry_url` variable |
| `ImagePullBackOff` | Credentials expired | Rotate registry credentials and recreate secret |

```bash
# Check pod for image pull error details
oc describe pod <pod-name> -n <namespace> | grep -A 5 "Events"

# Verify pull secret exists
oc get secret mstr-registry-pull-secret -n <namespace>

# Verify secret is linked to service account
oc describe sa default -n <namespace>
```

---

#### Issue: Service Mesh Problems

| Symptom | Likely Cause | Resolution |
|---|---|---|
| Pods not getting sidecar | Namespace not in SMMR | Add namespace to SMMR; rerun `smmr.yml` |
| 503 between services | mTLS policy misconfiguration | Review PeerAuthentication and DestinationRule objects |
| Envoy sidecar crash | Istio version incompatibility | Check OSSM operator version compatibility matrix |

```bash
# Check if sidecar is injected
oc get pods -n <namespace> -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.spec.containers[*].name}{"\n"}{end}'

# Check SMMR status
oc get smmr -n istio-system -o yaml
```

---

#### Issue: Operator Reconciliation Failures / CR Stuck in Provisioning

| Symptom | Likely Cause | Resolution |
|---|---|---|
| CR stuck in `Provisioning` | Operator pod crashed | Restart: `oc rollout restart deployment/mstr-operator -n mstr-operator` |
| CR stuck in `Provisioning` | RBAC permissions issue | Review operator ClusterRole permissions |
| Reconciliation loop error | Resource conflict | Check operator logs for conflict errors |

```bash
# Inspect operator logs
oc logs -n mstr-operator deployment/mstr-operator --tail=100

# Describe the MstrEnvironment CR
oc describe mstrenvironment <cr-name> -n <namespace>

# Check operator events
oc get events -n mstr-operator --sort-by='.lastTimestamp'
```

---

#### Issue: CrashLoopBackOff

| Symptom | Likely Cause | Resolution |
|---|---|---|
| IS pod `CrashLoopBackOff` | DB connection failure | Verify DB credentials and network reachability |
| IS pod `CrashLoopBackOff` | License validation failure | Check license secret contents |
| Web pod `CrashLoopBackOff` | Misconfigured IS endpoint | Check IS service name in ConfigMap |

```bash
# Get crash logs from previous container instance
oc logs <pod-name> -n <namespace> --previous

# Describe pod for event details
oc describe pod <pod-name> -n <namespace>
```

---

#### Issue: Readiness Probe Failures

| Symptom | Likely Cause | Resolution |
|---|---|---|
| Pod `Running` but not `Ready` | Application not fully initialized | Allow more time; increase `initialDelaySeconds` |
| Readiness probe HTTP 500 | Application startup error | Check application logs for startup exceptions |
| Probe connection refused | Wrong port configured | Verify probe port matches container port |

```bash
# Check readiness probe configuration
oc get pod <pod-name> -n <namespace> -o yaml | grep -A 10 "readinessProbe"

# Monitor probe status
oc get pods -n <namespace> -w
```

---

### Diagnostic Command Reference

```bash
# Full environment status
oc get all -n <namespace>

# MstrEnvironment CR details
oc describe mstrenvironment <cr-name> -n <namespace>

# All pod statuses
oc get pods -n <namespace> -o wide

# Pod logs (tail 200 lines)
oc logs <pod-name> -n <namespace> --tail=200

# Previous container logs (post-crash)
oc logs <pod-name> -n <namespace> --previous

# Cluster events (sorted by time)
oc get events -n <namespace> --sort-by='.lastTimestamp'

# Operator logs
oc logs -n mstr-operator deployment/mstr-operator -f

# Node resource availability
oc describe nodes | grep -E "Name:|Allocated resources:" -A 8

# PVC status
oc get pvc -n <namespace>

# Routes
oc get routes -n <namespace>
```

---

## 11. Enterprise Best Practices

### Production Deployment

- Always deploy to production through a CI/CD pipeline — never run `ansible-playbook` manually from a developer workstation in production.
- Use dedicated service accounts with least-privilege RBAC for the automation identity.
- Tag all resources with organizational labels (`environment`, `team`, `cost-center`, `version`) for cost allocation and lifecycle management.
- Store all playbook executions with their `csi_id` change ticket for audit compliance.

### High Availability Architecture

- Deploy Intelligence Server with a minimum of **2 replicas** across different nodes using pod anti-affinity rules.
- Deploy Library and Web with a minimum of **2 replicas** for zero-downtime deployments.
- Place the metadata repository (database) in a separate, highly available PostgreSQL or SQL Server cluster — never co-locate it in the same namespace as MicroStrategy pods.
- Configure **PodDisruptionBudgets** to prevent too many IS pods from being evicted simultaneously during node maintenance.

```yaml
# Example PodDisruptionBudget for Intelligence Server
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: is-pdb
  namespace: mstr-production
spec:
  minAvailable: 1
  selector:
    matchLabels:
      component: intelligence-server
```

### Resource Sizing

| Deployment Size | IS CPU | IS Memory | Web CPU | Web Memory |
|---|---|---|---|---|
| Small | 1 core | 4 Gi | 250m | 1 Gi |
| Medium | 2 cores | 8 Gi | 500m | 2 Gi |
| Large | 4 cores | 16 Gi | 1 core | 4 Gi |
| XLarge | 8 cores | 32 Gi | 2 cores | 8 Gi |

> **Recommendation:** Always set resource `requests` conservatively and `limits` at 2x requests for initial deployments. Profile actual usage under load and adjust accordingly.

### Monitoring and Logging

- Integrate IS pod logs with your central logging platform (e.g., Elasticsearch/Fluentd/Kibana stack in OpenShift).
- Configure Prometheus `ServiceMonitor` objects to scrape MicroStrategy metrics endpoints.
- Set up alerting for: pod restarts > 2 in 10 minutes, IS pod not ready for > 5 minutes, PVC utilization > 80%.
- Monitor OpenShift Route latency and HTTP error rates via the ingress controller metrics.

### Backup Strategy

| Data | Backup Method | Frequency |
|---|---|---|
| Metadata Repository (DB) | Database-native backup + WAL archiving | Continuous + daily full |
| Intelligence Server PVC | Volume snapshots via StorageClass | Daily |
| MstrEnvironment CR YAML | Git repository | On every change |
| Ansible Vault file | Encrypted Git repository | On every change |

### GitOps Integration

- Store all `MstrEnvironment` CR manifests in a Git repository.
- Use **OpenShift GitOps (ArgoCD)** to synchronize CR state from Git to the cluster.
- Implement branch protection rules: `main` branch changes require peer review.
- Use semantic versioning for CR manifests to track environment evolution.

### CI/CD Integration

```yaml
# Example pipeline stage (GitLab CI / Jenkins compatible)
deploy-mstr-environment:
  stage: deploy
  script:
    - ansible-playbook main.yml
        --vault-password-file $VAULT_PASSWORD_FILE
        -e "mstr_version=${MSTR_VERSION}"
        -e "namespace=${TARGET_NAMESPACE}"
        -e "csi_id=${CHANGE_TICKET}"
  environment:
    name: production
  only:
    - main
```

### Upgrade Planning

1. Test the new version in a non-production environment first.
2. Review the MicroStrategy upgrade guide for breaking changes.
3. Back up the metadata repository before initiating an upgrade.
4. Update `mstr_version` in the CR spec — the operator handles rolling upgrade coordination.
5. Monitor the `MstrEnvironment` CR status during upgrade.
6. Validate post-upgrade with smoke tests (authentication, report execution, Library access).

### Namespace Governance

- Create one namespace per environment (dev, staging, UAT, production).
- Apply `ResourceQuota` objects to prevent resource exhaustion.
- Apply `LimitRange` objects to enforce default resource requests/limits.
- Use OpenShift `Project` templates for consistent namespace provisioning.

---

## 12. Conclusion

### Summary

MicroStrategy environment deployment on OpenShift, when implemented using the MicroStrategy Kubernetes Operator and Ansible automation, provides a **reliable, repeatable, and production-grade** deployment model that aligns with modern platform engineering principles.

**Key Takeaways:**

- The `MstrEnvironment` Custom Resource provides a single, declarative interface for managing the full lifecycle of a MicroStrategy deployment.
- The MicroStrategy Operator continuously reconciles actual cluster state against the desired state, providing self-healing and drift correction at no additional operational cost.
- The Ansible `main.yml` playbook orchestrates all pre-deployment and post-deployment tasks — from cluster authentication through route exposure and notification — in a structured, auditable, and idempotent workflow.
- Ansible Vault ensures that sensitive configuration is encrypted at rest and never exposed in source control or logs.
- Structured error handling (rescue/always blocks), audit logging, and email notification provide the operational visibility required for enterprise environments.

### Next Steps

| Action | Owner | Priority |
|---|---|---|
| Review and validate `MstrEnvironment` CR spec for your target environment | Platform Engineer | High |
| Configure Ansible Vault with environment-specific secrets | Platform Engineer | High |
| Validate service mesh (OSSM) is installed and operational | OpenShift Administrator | High |
| Run the playbook in a staging namespace first | Platform Engineer | High |
| Configure Prometheus alerting for MicroStrategy pods | SRE / Monitoring Team | Medium |
| Integrate playbook into CI/CD pipeline | DevOps Engineer | Medium |
| Configure OpenShift GitOps (ArgoCD) for CR drift detection | Platform Engineer | Medium |
| Document environment-specific runbooks | Platform Engineer | Low |
| Establish backup and DR procedures for metadata repository | DBA / Platform Engineer | High |

---

*This document was generated from the MicroStrategy Environment deployment overview and operational workflow notes. For questions or updates, contact the Platform Engineering team.*

---

**Document Version:** 1.0  
**Last Updated:** 2026-05-07  
**Authors:** Platform Engineering Team
