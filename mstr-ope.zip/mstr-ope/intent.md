# intent.md
# MicroStrategy Operator on OpenShift – Enterprise Intent Document

## Purpose

This document defines the enterprise intent, deployment workflow, architecture decisions, operational practices, troubleshooting standards, CI/CD integration, security controls, and production deployment model for deploying the MicroStrategy Operator (Management Service) on Red Hat OpenShift.

This intent document is designed for:
- Claude Code
- Confluence generation
- Platform engineering documentation
- SRE runbooks
- Enterprise architecture reviews
- Banking/security audit reviews

---

# 1. Platform Overview

## Product
MicroStrategy ONE

## Component
Management Service / Operator

## Platform
Red Hat OpenShift

## Deployment Method
- mstrcli
- Helm
- Harness CD
- Tekton / OpenShift Pipelines
- GitOps-compatible workflows

---

# 2. Deployment Objectives

The deployment must achieve:

- Fully automated operator installation
- Enterprise-grade security
- GitOps compatibility
- CI/CD integration
- Private registry support
- Persistent storage integration
- TLS-secured access
- OpenShift-native deployment model
- Upgrade and rollback support

---

# 3. Core Architecture

## Components Installed

| Component | Type | Purpose |
|---|---|---|
| mstr-operator | Deployment | Kubernetes controller |
| API Layer | Deployment | Backend APIs |
| Web Layer | Deployment | Management UI |
| Validator | Deployment | Validation services |
| CRDs | Cluster-scoped | Custom resource definitions |

---

# 4. Interactive mstrcli Installation Flow

## Main Command

```bash
mstrcli
```

## Installation Path

```text
mstrcli
  → mgmt-svc
      → install
```

---

# 5. Namespace Design

Namespace used:

```text
mstr-operator
```

Purpose:
- Isolate workloads
- Simplify RBAC
- Simplify upgrades
- Separate operational ownership

---

# 6. Image Pull Secret Configuration

## Registry

```text
docker.artifactrepository.net
```

## Secret Name

```text
mstr-operator-default-image-pull-secret
```

## Purpose

Required for:
- Private image pulls
- Air-gapped environments
- Enterprise-controlled registries

---

# 7. Storage Configuration

## StorageClass

```text
sc-ontap-nas
```

## Backend

NetApp ONTAP + Trident CSI

## Access Mode

RWX (ReadWriteMany)

## Purpose

Persistent storage required for:
- Operator metadata
- Shared services
- Stateful components

---

# 8. TLS Configuration

## Development / Test

```yaml
tls:
  selfSigned: true
```

## Production

```yaml
tls:
  selfSigned: false
  secretName: mstr-enterprise-tls
```

## Production Recommendation

Use:
- Enterprise CA-signed certificates
- Kubernetes TLS secrets
- HTTPS-only routes

---

# 9. Helm-Based Installation

## Helm Command

```bash
helm upgrade --install mstr-operator \
  /opt/tableau/mstrCMC/Oct_CMC/mstr-operator.tgz \
  -n mstr-operator \
  -f values-openshift.yaml \
  --wait
```

## Why `upgrade --install`

Provides:
- First-time installation
- Upgrade support
- Idempotent automation
- CI/CD compatibility

---

# 10. values-openshift.yaml Example

```yaml
global:
  imageRegistry: docker.artifactrepository.net/biservicesstr/strsandbox2510
  imagePullSecrets:
    - name: mstr-operator-default-image-pull-secret

openshift:
  enabled: true

storage:
  storageClassName: sc-ontap-nas

tls:
  selfSigned: true

operator:
  replicas: 2

apiLayer:
  replicas: 2

webLayer:
  replicas: 2

validator:
  replicas: 1
```

---

# 11. OpenShift-Specific Behaviors

## Istio Labeling

Namespace automatically labeled:

```text
istio-injection=enabled
```

Purpose:
- Future service mesh support
- Envoy sidecar compatibility

---

# 12. Expose Operation

## Command

```text
mstrcli → mgmt-svc → expose
```

## What Happens

Creates:
- OpenShift Routes
- TLS bindings
- External access
- API exposure
- Web UI exposure

## Architecture

```text
User
 ↓
OpenShift Route
 ↓
OpenShift Router
 ↓
Service
 ↓
Pod
```

---

# 13. CI/CD Deployment Model

## Supported Tools

- Harness CD
- Tekton Pipelines
- OpenShift Pipelines
- GitLab CI
- Jenkins
- Argo CD

---

# 14. Harness CD Architecture

## Deployment Flow

```text
Git Repo
   ↓
Harness CD
   ↓
Helm Deploy
   ↓
OpenShift Cluster
   ↓
MicroStrategy Operator
```

## Key Benefits

- Audit trails
- Approval gates
- Rollback support
- Secure secret management
- GitOps integration

---

# 15. Tekton / OpenShift Pipelines

## High-Level Pipeline

```text
Create Namespace
   ↓
Create Image Pull Secret
   ↓
Label Namespace
   ↓
Helm Install
   ↓
Validation
```

---

# 16. Security Controls

## Required Controls

| Control | Status |
|---|---|
| Enterprise TLS | Required |
| Private Registry | Required |
| GitOps | Recommended |
| RBAC | Required |
| Namespace Isolation | Required |
| Audit Logs | Required |
| Non-root Containers | Required |

---

# 17. RBAC and SCC

## OpenShift Security Model

OpenShift enforces:
- Random UID execution
- SCC validation
- Restricted container permissions

## Common Fix

```bash
oc adm policy add-scc-to-user anyuid -z default -n mstr-operator
```

Purpose:
- Allow init containers
- Fix permission initialization issues

---

# 18. Common Deployment Problems

## Pods Stuck in Init State

Example:

```text
Init:0/2
```

Possible causes:
- Storage mount failure
- SCC restriction
- NFS export policy issue
- Image pull issue

---

# 19. Storage Failure Analysis

## Example Error

```text
MountVolume.SetUp failed
exit status 32
```

## Meaning

PVC is created but node cannot mount NFS volume.

## Important Clarification

PVC Bound ≠ successful mount.

Bound means:
- Volume exists

Mount means:
- Worker node can access storage

---

# 20. ONTAP / NFS Requirements

## Required Export Policy Settings

| Setting | Requirement |
|---|---|
| Access | Read/Write |
| Protocol | NFS |
| Root Squash | Disabled or mapped |
| Superuser | Allowed |
| Client Match | OCP worker subnet |

---

# 21. Storage Team Validation

## Required Test

```bash
mount -t nfs gtdvnasapp0004:/trident /mnt/test
```

If this fails:
- Storage export policy issue
- NFS permission issue
- Infrastructure issue

---

# 22. Troubleshooting Commands

## Pods

```bash
oc get pods -n mstr-operator
```

## PVC

```bash
oc get pvc -n mstr-operator
```

## Describe Pod

```bash
oc describe pod <pod-name> -n mstr-operator
```

## Logs

```bash
oc logs <pod-name> -n mstr-operator
```

---

# 23. Upgrade Strategy

## Upgrade Method

Replace:
- Helm chart version
- Image tags
- Values

Run:

```bash
helm upgrade --install
```

## Benefits

- Rolling upgrades
- Automated reconciliation
- Safe deployments
- CI/CD-friendly

---

# 24. Production TLS Migration

## Replace Self-Signed Certificates

### Create TLS Secret

```bash
oc create secret tls mstr-enterprise-tls \
  --cert=cert.pem \
  --key=key.pem \
  -n mstr-operator
```

### Update Helm Values

```yaml
tls:
  selfSigned: false
  secretName: mstr-enterprise-tls
```

---

# 25. Security Audit Readiness

## Enterprise Compliance Goals

Supports:
- SOX
- PCI-DSS
- ISO 27001
- Internal audit standards

## Audit Features

- Git-based changes
- Pipeline approvals
- Deployment audit logs
- Secure secrets
- Enterprise TLS
- RBAC isolation

---

# 26. Enterprise Operational Best Practices

## Recommended

- Use GitOps workflows
- Avoid manual production changes
- Use enterprise TLS
- Use private registries
- Enable monitoring/logging
- Use RBAC separation
- Use CI/CD pipelines
- Implement backup and rollback procedures

---

# 27. Final Enterprise Architecture

```text
Users
   ↓
Corporate DNS
   ↓
OpenShift Router
   ↓
OpenShift Routes
   ↓
MicroStrategy Services
   ↓
Pods
   ↓
Persistent Storage (ONTAP)
```

---

# 28. Executive Summary

The MicroStrategy Operator deployment on OpenShift is designed as an enterprise-grade, secure, automated, GitOps-compatible platform deployment using Helm, private registries, OpenShift-native networking, enterprise TLS, persistent ONTAP-backed storage, and CI/CD automation through Harness CD and Tekton pipelines.

The architecture supports:
- Production-scale deployments
- Banking/security compliance
- Automated upgrades
- Rollback strategies
- Infrastructure-as-code practices
- Enterprise auditability
