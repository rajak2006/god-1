# MicroStrategy Operator on OpenShift – Enterprise Deployment Guide

---

> **Document Status:** Draft – For Review  
> **Audience:** Platform Engineers, SRE Teams, Enterprise Architects, Security/Audit Reviewers  
> **Classification:** Internal – Confidential

---

## Table of Contents

1. [Overview](#overview)
2. [Objectives](#objectives)
3. [Scope](#scope)
4. [Key Features & Requirements](#key-features--requirements)
5. [Core Architecture](#core-architecture)
6. [Deployment Workflow](#deployment-workflow)
7. [Configuration Reference](#configuration-reference)
8. [CI/CD Integration](#cicd-integration)
9. [Security Controls & Compliance](#security-controls--compliance)
10. [Troubleshooting Guide](#troubleshooting-guide)
11. [Upgrade Strategy](#upgrade-strategy)
12. [Operational Best Practices](#operational-best-practices)
13. [Risks & Considerations](#risks--considerations)
14. [Dependencies](#dependencies)
15. [Next Steps](#next-steps)

---

## Overview

This document defines the enterprise intent, architecture decisions, deployment workflow, operational practices, troubleshooting standards, CI/CD integration, and security controls for deploying the **MicroStrategy Operator (Management Service)** on **Red Hat OpenShift**.

The MicroStrategy Operator is the Kubernetes-native controller responsible for managing the lifecycle of **MicroStrategy ONE** components within an enterprise OpenShift cluster. This deployment follows a GitOps-compatible, fully automated model that meets enterprise-grade security, compliance, and operational standards — including those applicable to banking, financial services, and regulated industries.

### Intended Audiences

| Audience | Use Case |
|---|---|
| Platform Engineers | Deployment, configuration, and pipeline setup |
| SRE / Operations Teams | Operational runbooks, troubleshooting, upgrades |
| Enterprise Architects | Architecture reviews, design decisions |
| Security / Audit Teams | SOX, PCI-DSS, ISO 27001 compliance review |
| Developers | Integration, CI/CD pipeline authoring |

---

## Objectives

The MicroStrategy Operator deployment on OpenShift is designed to achieve the following goals:

| Objective | Description |
|---|---|
| **Fully Automated Installation** | Operator lifecycle managed through scripted, repeatable deployments with no manual steps |
| **Enterprise-Grade Security** | TLS encryption, RBAC isolation, private registries, and SCC compliance |
| **GitOps Compatibility** | All configuration changes tracked in source control; no direct production mutations |
| **CI/CD Integration** | Pipeline-driven deployments via Harness CD, Tekton, or OpenShift Pipelines |
| **Private Registry Support** | All images sourced from enterprise-controlled artifact registries |
| **Persistent Storage Integration** | Stateful components backed by NetApp ONTAP via Trident CSI |
| **TLS-Secured Access** | All external and internal traffic encrypted using enterprise CA-signed certificates |
| **OpenShift-Native Model** | Leverages OpenShift Routes, SCCs, and native networking constructs |
| **Upgrade & Rollback Support** | Helm-based idempotent deployments with rollback capability |

---

## Scope

### In Scope

- Deployment of the MicroStrategy Operator (Management Service) on Red Hat OpenShift
- Helm-based and `mstrcli`-based installation workflows
- Namespace design, RBAC, and Security Context Constraint (SCC) configuration
- Image pull secret setup for enterprise private registries
- Persistent storage integration with NetApp ONTAP and Trident CSI
- TLS configuration for development and production environments
- CI/CD pipeline integration (Harness CD, Tekton, OpenShift Pipelines)
- Security controls and audit readiness guidance
- Troubleshooting procedures for common deployment failures
- Upgrade and rollback procedures

### Out of Scope

- MicroStrategy ONE application-level configuration (post-operator deployment)
- ONTAP storage provisioning and export policy management (storage team responsibility)
- Enterprise CA certificate issuance (PKI team responsibility)
- OpenShift cluster provisioning and infrastructure setup
- SSO / Identity Provider integration

---

## Key Features & Requirements

### Deployment Requirements

- OpenShift cluster with cluster-admin access (for CRD installation)
- Access to a private image registry (`docker.artifactrepository.net`)
- NetApp ONTAP storage with Trident CSI installed and `sc-ontap-nas` StorageClass available
- Helm 3.x installed on the deployment workstation or pipeline runner
- `mstrcli` binary available in PATH
- Valid enterprise TLS certificate and key (for production deployments)

### Functional Requirements

- The operator must reconcile MicroStrategy resource state continuously
- All components (API Layer, Web Layer, Validator) must support horizontal scaling via replica configuration
- Persistent volumes must use `ReadWriteMany (RWX)` access mode to support multi-pod access
- Namespace must be pre-labeled for Istio sidecar injection to support future service mesh adoption
- All secrets (image pull secrets, TLS secrets) must be created prior to Helm installation

---

## Core Architecture

### Installed Components

The Helm chart deploys the following workloads into the `mstr-operator` namespace:

| Component | Kind | Purpose |
|---|---|---|
| `mstr-operator` | Deployment | Kubernetes controller; manages the lifecycle of MicroStrategy custom resources |
| API Layer | Deployment | Exposes backend REST APIs for the Management Service |
| Web Layer | Deployment | Hosts the Management UI accessed by administrators |
| Validator | Deployment | Performs validation services for configuration and resource integrity |
| CRDs | Cluster-scoped resource | Custom Resource Definitions that extend the Kubernetes API for MicroStrategy resources |

> **Note:** CRDs are cluster-scoped and require cluster-admin privileges to install. They persist across namespace deletions.

### High-Level Architecture Diagram

```
Users
  │
  ▼
Corporate DNS
  │
  ▼
OpenShift Router (HAProxy / Ingress)
  │
  ▼
OpenShift Routes (TLS Terminated)
  │
  ▼
MicroStrategy Services
  ├── API Layer (Deployment)
  ├── Web Layer (Deployment)
  └── Validator (Deployment)
  │
  ▼
mstr-operator (Kubernetes Controller)
  │
  ▼
Persistent Storage (NetApp ONTAP via Trident CSI)
```

### Route Exposure Flow

When `mstrcli mgmt-svc expose` is executed, the following resources are created automatically:

```
User Request
  │
  ▼
OpenShift Route (external hostname, TLS)
  │
  ▼
OpenShift Router
  │
  ▼
Kubernetes Service (ClusterIP)
  │
  ▼
Pod (API / Web Layer)
```

---

## Deployment Workflow

### 1. Pre-Deployment Checklist

Before initiating deployment, confirm the following prerequisites are satisfied:

- [ ] OpenShift cluster is accessible and `oc login` is authenticated
- [ ] `mstrcli` binary is installed and in PATH
- [ ] Helm 3.x is installed
- [ ] The Helm chart archive (`mstr-operator.tgz`) is available at the expected path
- [ ] The private registry (`docker.artifactrepository.net`) is reachable from cluster nodes
- [ ] The `sc-ontap-nas` StorageClass exists and NFS export policies are configured
- [ ] TLS certificate and key files are available (for production deployments)
- [ ] Namespace `mstr-operator` has been created (or will be created by the pipeline)

---

### 2. Namespace Setup

The operator is deployed into a dedicated namespace to enforce workload isolation, simplified RBAC, and clear operational ownership.

```bash
oc new-project mstr-operator
```

**Label for Istio sidecar injection** (required for service mesh readiness):

```bash
oc label namespace mstr-operator istio-injection=enabled
```

**Purpose of namespace isolation:**

| Benefit | Description |
|---|---|
| Workload Isolation | Operator resources are separated from other cluster tenants |
| Simplified RBAC | Access policies scoped to a single namespace |
| Simplified Upgrades | Full namespace-scoped Helm release management |
| Operational Ownership | Clear team boundary for support and on-call responsibilities |

---

### 3. Image Pull Secret Configuration

All container images are sourced from the enterprise private registry. The image pull secret must be created before the Helm installation.

| Parameter | Value |
|---|---|
| Registry | `docker.artifactrepository.net` |
| Secret Name | `mstr-operator-default-image-pull-secret` |
| Namespace | `mstr-operator` |

```bash
oc create secret docker-registry mstr-operator-default-image-pull-secret \
  --docker-server=docker.artifactrepository.net \
  --docker-username=<REGISTRY_USER> \
  --docker-password=<REGISTRY_PASSWORD> \
  -n mstr-operator
```

> **Security Note:** Registry credentials must be stored in a secrets manager (e.g., HashiCorp Vault, OpenShift Secrets) and injected at pipeline runtime. Never hardcode credentials in pipeline definitions or values files.

---

### 4. Interactive Installation via mstrcli

`mstrcli` provides an interactive CLI-driven installation path suited for initial setup and operator-guided deployments.

**Installation path:**

```
mstrcli
  └── mgmt-svc
        └── install
```

Run the command:

```bash
mstrcli mgmt-svc install
```

The CLI will prompt for configuration values including namespace, registry settings, storage class, and TLS options.

---

### 5. Helm-Based Installation (Recommended for CI/CD)

Helm is the preferred installation method for automated and CI/CD-driven deployments due to its idempotent behavior and upgrade support.

```bash
helm upgrade --install mstr-operator \
  /opt/tableau/mstrCMC/Oct_CMC/mstr-operator.tgz \
  -n mstr-operator \
  -f values-openshift.yaml \
  --wait
```

**Why `helm upgrade --install`?**

| Behavior | Description |
|---|---|
| First-time install | Installs the release if it does not exist |
| Upgrade | Applies configuration changes if the release already exists |
| Idempotency | Safe to run repeatedly without side effects |
| CI/CD compatibility | No conditional logic needed in pipelines |

---

### 6. Expose the Management Service

After installation, expose the operator's API and Web UI via OpenShift Routes:

```bash
mstrcli mgmt-svc expose
```

This command creates:
- OpenShift Route for the API Layer
- OpenShift Route for the Web Layer
- TLS bindings on routes (based on configured certificate)
- External DNS-accessible hostnames

---

## Configuration Reference

### Helm Values File: `values-openshift.yaml`

The following is the reference configuration for OpenShift deployments:

```yaml
global:
  imageRegistry: docker.artifactrepository.net/biservicesstr/strsandbox2510
  imagePullSecrets:
    - name: mstr-operator-default-image-pull-secret

openshift:
  enabled: true            # Enables OpenShift-specific behaviors (SCC, Routes)

storage:
  storageClassName: sc-ontap-nas

tls:
  selfSigned: true         # Set to false for production; use secretName below

operator:
  replicas: 2

apiLayer:
  replicas: 2

webLayer:
  replicas: 2

validator:
  replicas: 1
```

> **Important:** The `openshift.enabled: true` flag activates OpenShift-specific behaviors including Route creation and SCC-compatible pod security settings.

---

### Storage Configuration

| Parameter | Value |
|---|---|
| StorageClass | `sc-ontap-nas` |
| Backend | NetApp ONTAP with Trident CSI Driver |
| Access Mode | `ReadWriteMany (RWX)` |

**Why RWX?**
Multiple pods (operator replicas, API Layer, Web Layer) require concurrent access to shared persistent volumes. NFS-backed ONTAP volumes support RWX natively.

---

### TLS Configuration

#### Development / Test

```yaml
tls:
  selfSigned: true
```

Self-signed certificates are acceptable for non-production environments. Browsers will display security warnings.

#### Production

```yaml
tls:
  selfSigned: false
  secretName: mstr-enterprise-tls
```

Create the TLS secret from enterprise CA-issued certificate and key:

```bash
oc create secret tls mstr-enterprise-tls \
  --cert=cert.pem \
  --key=key.pem \
  -n mstr-operator
```

> **Recommendation:** Use enterprise CA-signed certificates, enforce HTTPS-only routes, and rotate certificates before expiry via automated certificate management (e.g., cert-manager).

---

## CI/CD Integration

### Supported CI/CD Tools

| Tool | Use Case |
|---|---|
| **Harness CD** | Enterprise CD with approval gates, audit trails, and rollback |
| **Tekton / OpenShift Pipelines** | Native OpenShift pipeline execution |
| **GitLab CI** | Source-integrated pipeline with merge request gates |
| **Argo CD** | GitOps continuous delivery and drift detection |
| **Jenkins** | Legacy pipeline support |

---

### Harness CD Deployment Flow

```
Git Repository (Helm values, chart version)
  │
  ▼
Harness CD Pipeline
  │  ├── Approval Gate (required for production)
  │  ├── Secret injection (registry credentials, TLS)
  │  └── Deployment stage
  ▼
Helm Deploy (upgrade --install)
  │
  ▼
OpenShift Cluster
  │
  ▼
MicroStrategy Operator (Deployed / Upgraded)
```

**Key Harness CD Benefits:**

- Full deployment audit trail with timestamps and approvers
- Manual approval gates before production promotion
- One-click rollback to any prior release
- Secure secret injection at runtime (no secrets in source control)
- GitOps-compatible trigger on merge to main branch

---

### Tekton / OpenShift Pipelines

The following pipeline task sequence represents the recommended Tekton pipeline structure:

```
Task 1: Create Namespace (oc new-project mstr-operator)
  │
  ▼
Task 2: Create Image Pull Secret
  │
  ▼
Task 3: Label Namespace (istio-injection=enabled)
  │
  ▼
Task 4: Helm Install / Upgrade
  │
  ▼
Task 5: Validation (oc get pods, health checks)
```

Each task should be defined as a reusable Tekton `Task` resource and composed in a `Pipeline` resource for orchestration.

---

## Security Controls & Compliance

### Security Control Matrix

| Control | Requirement | Status |
|---|---|---|
| Enterprise TLS | Mandatory for production | Required |
| Private Image Registry | All images from internal registry | Required |
| Namespace Isolation | Dedicated `mstr-operator` namespace | Required |
| RBAC | Least-privilege service accounts and roles | Required |
| Non-Root Containers | No containers run as UID 0 | Required |
| Audit Logs | Pipeline and OpenShift audit logs enabled | Required |
| GitOps Workflow | No direct production mutations | Recommended |
| Secrets Management | Secrets injected at runtime, not stored in Git | Required |

---

### RBAC and Security Context Constraints (SCC)

OpenShift enforces a stricter security model than vanilla Kubernetes:

- **Random UID execution**: OpenShift assigns a random UID to containers by default
- **SCC validation**: Pods must be compliant with the assigned SCC before scheduling
- **Restricted container permissions**: Privileged containers are blocked by default

**If init containers fail due to SCC restrictions**, apply the following fix:

```bash
oc adm policy add-scc-to-user anyuid -z default -n mstr-operator
```

> **Note:** Granting `anyuid` allows pods to run as any UID, including root. Apply this only when required, and document the justification for audit purposes. Where possible, prefer configuring the operator image to be compatible with restricted SCC.

---

### Compliance Frameworks Supported

| Framework | Applicable Controls |
|---|---|
| **SOX** | Audit trails, change management, approval gates |
| **PCI-DSS** | Encryption in transit (TLS), access control (RBAC), audit logging |
| **ISO 27001** | Information security controls, access management, change control |
| **Internal Audit** | Git-based change history, pipeline approvals, deployment logs |

---

## Troubleshooting Guide

### Common Issue: Pods Stuck in Init State

**Symptom:**

```
NAME                        READY   STATUS     RESTARTS   AGE
mstr-operator-xxxx          0/2     Init:0/2   0          5m
```

**Possible Causes & Resolution:**

| Cause | Diagnostic | Resolution |
|---|---|---|
| Storage mount failure | `oc describe pod <pod-name> -n mstr-operator` → check `Events` | Verify NFS export policy; validate manual mount |
| SCC restriction | Check events for `forbidden` errors | Apply `anyuid` SCC or update pod security policy |
| NFS export policy | Manual mount test from a worker node | Coordinate with storage team |
| Image pull failure | Check for `ImagePullBackOff` in pod events | Verify image pull secret and registry reachability |

---

### Common Issue: Storage Mount Failure

**Error Example:**

```
MountVolume.SetUp failed for volume "pvc-xxxxx" :
rpc error: exit status 32
```

**Root Cause:** The PVC is in `Bound` state but the worker node cannot mount the NFS export.

> **Important Distinction:**
>
> | State | Meaning |
> |---|---|
> | PVC `Bound` | The persistent volume exists in ONTAP and is allocated |
> | Mount `Success` | The worker node OS can actively read/write the NFS share |
>
> A bound PVC does **not** guarantee a successful mount. Always verify the mount independently.

**Resolution Steps:**

1. Identify the worker node where the pod is scheduled:
   ```bash
   oc describe pod <pod-name> -n mstr-operator | grep Node:
   ```

2. Test manual NFS mount from the worker node (coordinate with storage team):
   ```bash
   mount -t nfs gtdvnasapp0004:/trident /mnt/test
   ```

3. If the manual mount fails, escalate to the storage team with the NFS server path and worker node subnet.

---

### ONTAP / NFS Export Policy Requirements

For Trident-provisioned volumes to mount successfully, the ONTAP export policy must be configured as follows:

| Setting | Required Value |
|---|---|
| Access | Read/Write |
| Protocol | NFS |
| Root Squash | Disabled or mapped to a valid UID |
| Superuser Access | Allowed |
| Client Match | OpenShift worker node subnet (CIDR) |

---

### Diagnostic Commands Reference

| Purpose | Command |
|---|---|
| List all pods in namespace | `oc get pods -n mstr-operator` |
| List all PVCs | `oc get pvc -n mstr-operator` |
| Describe a pod (events, mounts) | `oc describe pod <pod-name> -n mstr-operator` |
| View pod logs | `oc logs <pod-name> -n mstr-operator` |
| Check routes | `oc get routes -n mstr-operator` |
| Check Helm release status | `helm status mstr-operator -n mstr-operator` |
| Check Helm history | `helm history mstr-operator -n mstr-operator` |

---

## Upgrade Strategy

### Upgrade Method

MicroStrategy Operator upgrades are performed via Helm by updating the chart version, image tags, and/or values, then re-running the idempotent install command:

```bash
helm upgrade --install mstr-operator \
  /opt/tableau/mstrCMC/<NewVersion>/mstr-operator.tgz \
  -n mstr-operator \
  -f values-openshift.yaml \
  --wait
```

### Upgrade Process

1. **Prepare:** Update `values-openshift.yaml` with new image tags or configuration changes
2. **Review:** Perform a dry-run to validate changes: `helm upgrade --install --dry-run ...`
3. **Approve:** Obtain pipeline approval gate sign-off (for production)
4. **Execute:** Run `helm upgrade --install` via pipeline
5. **Validate:** Confirm all pods reach `Running` state; run smoke tests against API and Web Layer
6. **Rollback (if needed):** `helm rollback mstr-operator <REVISION> -n mstr-operator`

### Upgrade Benefits

| Feature | Description |
|---|---|
| Rolling Updates | Pods updated one at a time to maintain availability |
| Automated Reconciliation | Operator self-heals after configuration drift |
| Safe Deployments | `--wait` flag ensures Helm reports failure if rollout fails |
| Revision History | Helm tracks all past revisions for rollback |

---

## Operational Best Practices

The following practices are strongly recommended for production deployments:

| Practice | Rationale |
|---|---|
| Use GitOps workflows for all changes | Ensures traceability and prevents configuration drift |
| Never make direct changes to production | Bypasses audit trail and increases risk of human error |
| Use enterprise CA-signed TLS certificates | Required for compliance; self-signed certs not acceptable in production |
| Source all images from private registry | Prevents dependency on public registries; supports air-gapped environments |
| Enable monitoring and centralized logging | Required for SRE observability and incident response |
| Implement RBAC with least-privilege principles | Limits blast radius of compromised credentials |
| Use CI/CD pipelines for all deployments | Enables reproducibility, approval gates, and audit trails |
| Implement backup and rollback procedures | Helm history provides rollback; document ONTAP snapshot policies |
| Rotate secrets and certificates regularly | Reduces risk window from credential compromise |
| Test upgrades in non-production first | Prevents production incidents from untested configuration changes |

---

## Risks & Considerations

| Risk | Severity | Mitigation |
|---|---|---|
| **NFS mount failure blocking pod startup** | High | Pre-validate export policies with storage team; include mount test in pipeline pre-checks |
| **Self-signed TLS in production** | High | Enforce enterprise CA certificates via values file; block self-signed in production pipeline |
| **SCC policy blocking init containers** | Medium | Document and pre-approve `anyuid` SCC grants; test in non-prod before production rollout |
| **Image pull failure in air-gapped environment** | High | Ensure all images are pre-mirrored to private registry; validate pull secret before deployment |
| **CRD conflicts from previous installations** | Medium | Include CRD cleanup step in re-installation runbook; coordinate with platform team |
| **Secrets in Git repository** | Critical | Enforce secrets management tool usage; scan Git history for accidental secret commits |
| **Manual production changes causing drift** | Medium | Enforce GitOps policy; restrict direct `oc apply` access in production namespace |
| **Certificate expiry causing service outage** | High | Implement certificate rotation automation (cert-manager); configure expiry alerting |
| **Namespace deletion removing Helm state** | Low | Document Helm release state; Helm state stored in Secrets within the namespace |

---

## Dependencies

### Infrastructure Dependencies

| Dependency | Version / Detail | Owner |
|---|---|---|
| Red Hat OpenShift | 4.x (compatible version required) | Platform Engineering |
| NetApp ONTAP | ONTAP with Trident CSI Driver | Storage Team |
| Trident CSI Driver | Installed on cluster; `sc-ontap-nas` StorageClass present | Storage / Platform Team |
| Private Image Registry | `docker.artifactrepository.net` accessible from cluster | Platform / Registry Team |
| Enterprise PKI / CA | CA-signed TLS certificate and key for production | Security / PKI Team |

### Software Dependencies

| Dependency | Purpose |
|---|---|
| `mstrcli` | Interactive CLI installer for MicroStrategy Operator |
| Helm 3.x | Kubernetes package manager for chart-based deployments |
| `oc` CLI (OpenShift Client) | Cluster administration and resource management |
| Harness CD | Enterprise CD pipeline for production deployments |
| Tekton / OpenShift Pipelines | Native pipeline execution within the cluster |

### External Service Dependencies

| Service | Purpose |
|---|---|
| Corporate DNS | Name resolution for exposed OpenShift Route hostnames |
| ONTAP NFS Server (`gtdvnasapp0004`) | NFS endpoint for persistent volume mounts |
| Istio / Service Mesh (future) | Namespace pre-labeled; sidecar injection ready for future enablement |

---

## Next Steps

The following actions are required to complete the deployment and operationalize the platform:

| Priority | Action Item | Owner | Notes |
|---|---|---|---|
| **P0** | Validate ONTAP NFS export policies for worker node subnets | Storage Team | Blocker for pod startup |
| **P0** | Provision enterprise TLS certificate for production route | Security / PKI Team | Required before production launch |
| **P1** | Configure Harness CD pipeline with approval gates for production | Platform Engineering | Required for compliant deployments |
| **P1** | Create and validate image pull secret in `mstr-operator` namespace | Platform Engineering | Blocker for image pull |
| **P1** | Verify Trident CSI and `sc-ontap-nas` StorageClass availability | Storage / Platform Team | Required for PVC provisioning |
| **P2** | Implement Tekton pipeline for automated deployment in non-production | Platform Engineering | Enable pipeline testing prior to Harness CD setup |
| **P2** | Configure centralized logging and monitoring for `mstr-operator` namespace | SRE Team | Required for observability and incident response |
| **P2** | Document and test rollback procedure end-to-end | Platform / SRE Team | Required for production readiness sign-off |
| **P3** | Enable Istio service mesh sidecar injection (namespace already labeled) | Platform Engineering | Future enhancement; namespace pre-prepared |
| **P3** | Implement automated certificate rotation via cert-manager | Security / Platform Team | Prevents certificate expiry outages |

---

## Document History

| Version | Date | Author | Change Summary |
|---|---|---|---|
| 1.0 | 2026-05-07 | Platform Engineering | Initial document created from intent.md |

---

*This document was generated from the enterprise intent specification for the MicroStrategy Operator on OpenShift deployment. It is intended for use by platform engineering, SRE, enterprise architecture, and security audit teams.*
